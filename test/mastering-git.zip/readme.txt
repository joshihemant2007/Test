These files are not really "exercises", although that's what the Pluralsight site calls them. They contain two things:

1 - The slides of this training, in a more compact, non-animated form that you can use to review the content.
2 - The repository that I used in the screencast, copied after the end of each training module. You can use it to make your own experiments. Also, if you're like me, you'll find it much easier to remember the commands if you type them yourself.

Also, the example project for this training is on GitHub (https://github.com/nusco/cookbook). Use this command to clone it to your computer:

    git clone https://github.com/nusco/cookbook

I love feedback, so I hope to meet you on this training's discussion forum. Have fun, and enjoy Mastering Git!

   Paolo Perrotta
