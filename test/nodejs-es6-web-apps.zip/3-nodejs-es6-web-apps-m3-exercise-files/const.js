const env = 'debug';

if(true){
	const env = 'prod';
	console.log(env);
}

console.log(env);