console.log(x);

let x = 1;

//more code.... 

for(let x = 0; x<10; x++){
	console.log(x);
}

console.log('x = ' + x);