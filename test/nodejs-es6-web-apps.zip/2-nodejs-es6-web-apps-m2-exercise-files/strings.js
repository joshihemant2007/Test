var name = 'Luke'

var message = 'How are you?'

console.log('Hello ' + name + '. ' + message);

console.log(`Hello ${name}. ${message}`);