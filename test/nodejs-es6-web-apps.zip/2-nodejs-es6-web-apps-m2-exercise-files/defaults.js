
function sum(x,y){
	if(typeof y === 'undefined'){
		y=0;
	}
	return x+y;
}

console.log(sum(0)); // returns 0