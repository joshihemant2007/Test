var oct = 010;
var oct = 0o10;
var bin = 0b11;

console.log(oct);
console.log(bin);