console.log('App loaded!');
var config = require('../config/config.json');

console.log(config.app_loaded_msg);

