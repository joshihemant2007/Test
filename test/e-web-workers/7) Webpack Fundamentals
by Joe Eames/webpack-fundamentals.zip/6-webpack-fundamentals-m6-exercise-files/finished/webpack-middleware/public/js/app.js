console.log('App loaded!');

require('../css/style.css');


