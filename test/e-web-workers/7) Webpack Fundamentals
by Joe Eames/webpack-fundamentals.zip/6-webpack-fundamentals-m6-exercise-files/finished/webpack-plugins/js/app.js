console.log('App loaded');

$('#testDiv').text('jQuery modified this content(see app.js)');

require('./login');
