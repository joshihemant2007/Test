// This is global JS provided to all apps.
console.log('logging from the utils.js file...');


