require('./login');

document.write("Welcome to Big Hair Concerts!!");

console.log('App loaded');
