var angular = require('angular');
var app = angular.module('app', []);

require('./bands')(app);
