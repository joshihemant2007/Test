console.log('Home page JS loaded');

