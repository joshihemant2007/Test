ReactDOM.render(
    <div>
    <h1>Hello World!</h1>
    <p>This is some content.</p>
    </div>,
    document.getElementById('content')
)
