run `npm install` from the command-line or terminal to install all node modules needed to compile the project

