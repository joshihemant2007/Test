run `npm install` from the command-line or terminal to install all node modules needed to run the project

use WebStorm or your IDE's built-in web server to run index.html
OR
`npm install serve` to install a node web server you can use from a text editor