
var values = [3,1,2];
var result = values.sort((a,b)=> a-b);
console.log(result);