import {operations} from './arithmetic.js';

let result = operations.add(1,1);
console.log(result);

result = operations.subtract(3,1);
console.log(result);



