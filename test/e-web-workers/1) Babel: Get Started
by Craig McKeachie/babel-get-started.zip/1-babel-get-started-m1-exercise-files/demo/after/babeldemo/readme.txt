You will need to run the command:

npm install

from the directory where this file lives for the code to compile as shown in the demos. This will install all the dependencies in package.json


