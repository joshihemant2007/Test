

console.log("##Modules");


import {operations} from './arithmetic.js';

let moduleResult = operations.add(1, 1);
console.log(moduleResult);

moduleResult = operations.subtract(3, 1);
console.log(moduleResult);




