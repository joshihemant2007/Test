(function () {
    "use strict";

    console.log("##Binary and Octal Literals");
    console.log(0b111110111 === 503);
    console.log(0o767 === 503);


})();
