var promise = new Promise(function (resolve, reject) {});
