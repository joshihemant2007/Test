const format = require('./dateFormatter');

exports.helloHTTP = function helloHTTP(req, res) {
    res.status(200).send(format.formattedDate());
}

exports.psHelloPubSub = function helloPubSub(event, callback) {
    console.log(`Hello PubSub ${format.formattedDate()}`);
    callback();
}

exports.psHelloStorage = function helloStorage(event, callback) {
    console.log(`Hello Storage ${format.formattedDate()}`);
    callback();
}