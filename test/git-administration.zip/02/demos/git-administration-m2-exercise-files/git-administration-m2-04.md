# Configuring a Base Virtual Machine

In this clip, we will configure two virtual machines: one as our internal Git server and one as our Git client.  Both of these will be Ubuntu Server 18.04 LTS instances. To simulate the Globomantics data center, we will be launching these instances in a Virtual Private Cloud on AWS.  If you don't have AWS experience, this is still relatively easy to configure.  If you would rather utilize local virtual machines, you can simply start with the base version of Ubuntu Server 18.04 on whichever virtualization platform that you prefer. If you would rather use another cloud platform, the steps will be similar on your desired platform.

## Launching the Virtual Machines

The first step will be to navigate to the AWS console.
```
https://aws.amazon.com/console/
```

From here, you will be able to log into your AWS account.  We will nativate to EC2, AWS's elastic compute cloud, to launch our instances. 
```
Select the EC2 service
```

Next, we will select the **Launch Instances** button.
```
Click Launch Instance
```

We will select the `Ubuntu Server` AMI by pressing the Select button next to the listing.
```
Click Select button
```

We will leave the default instance type selected.  Since this is a `t2.micro` it is eligible for the free tier.  Press the **Next** button.
```
Click the Next: Configure Instance Details button
```

From the Configure Instance Details view, we need to update two values.  First, set the `Number of Instances` to 2.  Next, set the `Auto-assign Public IP` to Enable.
```
Set Instances to 2
Set Auto-assign Public IP to Enable
```

Next, press `Review and Launch`.
```
Press Review and Launch
```

Select `Launch`.
```
Press Launch
```

Either select an existing key pair or create a new one.  This is what we will use to SSH into these instances.
```
Select key pair and press Launch Instances
```

Next, we will navigate to instances.  We will select a server and then go to the `Tags` tab. Set the `Name` tag to `Git Server`.
```
Git Server
```

Next, select the other server and give it a `Name` tag of `Git Client`.
```
Git Client
```

## Connecting to the Git Server

Select the server that has the name, `Git Server`.  Copy the Public DNS name for the server from the Description tab.
```
Copy Public DNS Name
```

From your command line, SSH into the machine and accept the host key (substitute the host DNS name and path to AWS keypair):
```
ssh -i ~/keypair.pem ubuntu@<server hostname>
```

Next, we need to be sure that we have updates the packages on the server.
```
sudo apt-get update && sudo apt-get -y upgrade
```

Verify the OS version that we are using:
```
lsb_release -a
```

Verify the Git version we have:
```
git --version
```

## Connecting to the Git Client


Select the server that has the name, `Git Client`.  Copy the Public DNS name for the server from the Description tab.
```
Copy Public DNS Name
```

From your command line, SSH into the machine and accept the host key (substitute the host DNS name and path to AWS keypair):
```
ssh -i ~/keypair.pem ubuntu@<server hostname>
```

Next, we need to be sure that we have updates the packages on the server.
```
sudo apt-get update && sudo apt-get -y upgrade
```

Verify the Git version we have:
```
git --version
```

## Using the Local Protocol on the Client

Let's initially leverage the local protocol on the client machine.  This would be leveraged if you had an external mount and wanted to use file permissions to control access to the server.
```
cd ~
mkdir -p server/repo.git
```

Next, let's change into the directory, and create a new `bare` git repository.
```
cd server/repo.git
git --bare init
```

Next, let's change back to our home directory and clone the repository:
```
cd ~
git clone ~/server/repo.git
```

Next, we will create the readme in the repository.
```
cd repo
echo "New Project" >> README.md
```

Next, we will commit these changes:
```
git add .
git commit -m "Initial Commit"
git push origin master
```

We have now pushed to a local repository using the Git local protocol on our client server.  Next, we will transition to leveraging the SSH protocol to communicate between our client and server instances.
