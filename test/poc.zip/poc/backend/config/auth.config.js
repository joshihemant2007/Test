module.exports = {
    secret: 'react-node-application'
}