module.exports = (sequelize, Sequelize) => {
    const Blog = sequelize.define('blog', {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            allowNull: false,
            primaryKey: true
        },
        title: {
            type: Sequelize.STRING
        },
        imageUrl: {
            type: Sequelize.STRING
        },
        description: {
            type: Sequelize.TEXT
        }
    })

    return Blog
}