const config = require('../config/db.config')

const Sequelize = require('sequelize')
const Op = Sequelize.Op

const operatorsAliases = {
    $like: Op.like,
    $not: Op.not
}

const sequelize = new Sequelize(
    config.DB,
    config.USER,
    config.PASSWORD,
    {
        host: config.HOST,
        dialect: config.dialect,
        operatorsAliases: false
    },
    { operatorsAliases },
)

const db = {}

db.Sequelize = Sequelize
db.sequelize = sequelize

db.user = require('../models/user.model')(sequelize, Sequelize)
db.role = require('../models/role.model')(sequelize, Sequelize)
db.blog = require('../models/blog.model')(sequelize, Sequelize)

db.role.belongsToMany(db.user, {
    through: 'user_roles',
    foreignKey: 'roleId',
    otherKey: 'userId'
})
db.user.belongsToMany(db.role, {
    through: 'user_roles',
    foreignKey: 'userId',
    otherKey: 'roleId'
})
db.blog.belongsTo(db.user, {
    constraint: true,
    onDelete: 'CASCADE'
})
db.user.hasMany(db.blog)

db.ROLES = ['user', 'admin', 'blogger']

module.exports = db