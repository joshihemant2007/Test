const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors')
const fs = require('fs')
const path = require('path')

const helmet = require('helmet') // securing response by adding headers
const compression = require('compression') // reducing size of assets can be seen in the network tab
const morgan = require('morgan') // for logging request details in terminal or file

const port = process.env.PORT || 8080

const app = express()

var corsOptions = {
    origin: 'http://localhost:3000', // react app is at port 3000
}
app.use(cors(corsOptions))

const accessLogStream = fs.createWriteStream(
    path.join(__dirname, 'access.log'),
    { flags: 'a'}
)

app.use(helmet())
app.use(compression())
// app.use(morgan('combined', { stream: accessLogStream })) // if no stream then logs in terminal

// parse requests of content-type - application/json
app.use(bodyParser.json())

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }))

// Serve Files static
app.use('/public', express.static('public'))

// Multer for files
// FOR PROFILE AVATAR, CODE IS AT user route
// // app.use(multer().single('imageUrl'))
// var storage = multer.diskStorage({
//     destination: function (req, file, cb) {
//         cb(null, 'public')
//     },
//     filename: function (req, file, cb) {
//         cb(null, Date.now() + '-' + file.originalname)
//     }
// })
// var uploadAvatar = multer({ storage: storage }).array('avatar') // avatar must match with key in form-data in postman


const db = require('./models')
const Role = db.role

db.sequelize.sync()
// force: true will drop the table if it already exists
// db.sequelize.sync({force: true}).then(() => {
//   console.log('Drop and Resync Database with { force: true }')
//   initial()
// })

function initial() {
    Role.create({
        id: 1,
        name: 'admin'
    })

    Role.create({
        id: 2,
        name: 'blogger'
    })

    Role.create({
        id: 3,
        name: 'user'
    })
}

// routes
require('./routes/auth.routes')(app)
require('./routes/user.routes')(app)
require('./routes/blog.routes')(app)

// Express built in middleware
// It accepts error as 1st param
// It will be executed by default when
// in then:->       error = new Error('Dummmy'); throw error;
// and in catch:->  const error = new Error(err); return next(error);
app.use((error, req, res, next) => {
    // res.status(500).send('Error occured')

    // This will execute when we throw error with next()
    console.log('Express Error Middleware: ', error)
    const status = error.statusCode || 500
    const message = error.message // default error.message available
    const data = error.data

    res.status(status).json({ message, data })
})

// development mode: npm run dev
// production mode: npm start
console.log(process.env.NODE_ENV + " Mode started!!!")

app.listen(port, () => {
    console.log(`Server is running on port ${port}`)
})
