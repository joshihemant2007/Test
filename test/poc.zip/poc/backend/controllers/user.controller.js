const db = require('../models')
const User = db.user
const sharp = require('sharp')
const utility = require('../utility/helper')
const fs = require('fs')

exports.allAccess = (req, res) => {
    res.status(200).send('Public Content.')
}

exports.userBoard = (req, res) => {
    res.status(200).send('User Content.')
}

exports.adminBoard = (req, res) => {
    res.status(200).send('Admin Content.')
}

exports.bloggerBoard = (req, res) => {
    res.status(200).send('Blogger Content.')
}

exports.getProfileById = (req, res, next) => {
    const userId = req.params.id

    User
        .findByPk(userId)
        .then(user => {
            if (!user) {
                return res.status(400).send({
                    message: 'No user found'
                })
            }
            // console.log(user.name)
            res.status(200).send({
                'user': {
                    name: user.name,
                    email: user.email,
                    avatar: user.avatar
                }
            })
        })
        .catch(err => console.log(err))
}

// Update Profile
exports.postUpdateProfile = (req, res, next) => {
    const userId = req.userId
    const name = req.body.name
    const deleteAvatar = req.body.deleteAvatar
    // const renamedFileName = req.body.renamedFileName
    const renamedFilePath = req.body.renamedFilePath
    const resizedFilePath = req.body.resizedFilePath
    // const avatar = req.file // if no sharp middleware, then direct comes in req.file

    User
        .findByPk(userId)
        .then(user => {
            // error = new Error() // when no error message then at frontend Request failed with status code 500
            // error = new Error('This is message from profile page')
            // throw error;
            if (!user) {
                return res.status(400).send({
                    message: 'No user found'
                })
            }
            req.user.name = name

            if (deleteAvatar === '0') {
                if (resizedFilePath) {
                    if (user.avatar) {
                        originlFilaName = user.avatar.split('./public/images/avatars/thumb_250_250_')[1];
                        originlFilaPath = './public/images/avatars/' + originlFilaName

                        // fs.unlink(user.avatar, (err) => {

                        // })
                        // fs.unlink(originlFilaPath, (err) => {

                        // })
                        utility.deleteFile(user.avatar)
                        utility.deleteFile(originlFilaPath)
                    }
                    req.user.avatar = resizedFilePath
                }
            } else {
                req.user.avatar = ''
            }

            req.user
                .save()
                .then(() => {
                    if (deleteAvatar === '1') {
                        if (user.avatar) {
                            originlFilaName = user.avatar.split('./public/images/avatars/thumb_250_250_')[1];
                            originlFilaPath = './public/images/avatars/' + originlFilaName
                            // fs.unlink(user.avatar, (err) => {

                            // })
                            // fs.unlink(originlFilaPath, (err) => {

                            // })
                            utility.deleteFile(user.avatar)
                            utility.deleteFile(originlFilaPath)
                        }
                        // if (renamedFilePath) {
                        //     fs.unlink(renamedFilePath, (err) => {
                        //         // if (err) {
                        //         //     console.log(err)
                        //         //     throw (err)
                        //         // }
                        //     })
                        // }
                    }
                })
                .then(() => {
                    res.status(200).send({
                        name,
                        avatar: resizedFilePath,
                        message: 'Profile updated successfully'
                    })
                })
        }).catch(err => {
            console.log(err)
            const error = new Error(err)
            error.httpStatusCode = 500
            return next(err)
        })
}
