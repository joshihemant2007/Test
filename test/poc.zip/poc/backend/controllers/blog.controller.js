const db = require('../models')
const Blog = db.blog
const User = db.user
const Op = db.Sequelize.Op;

// Create
exports.add = (req, res, next) => {
    const title = req.body.title
    const imageUrl = req.file
    const description = req.body.description

    req.user
        .createBlog({
            title,
            imageUrl,
            description
        })
        .then(blog => {
            if (!blog) {
                return res.status(400).send({
                    message: 'Error in creating blog'
                })
            }

            res.status(201).send({
                message: 'Blog created'
            })
        })
        .catch(err => console.log(err))
}

// Read All
exports.blog = (req, res, next) => {
    Blog.findAll({
        // attributes: ['id', 'title', 'imageUrl', 'description'],
        include: [{
            model: User,
            attributes: ['id', 'name', 'email'],
            where: { id: db.Sequelize.col('blog.userId') }
        }]
    })
        .then(blogs => {
            res.status(200).send({
                blogs
            })
        })
        .catch(err => console.log(err))
}

// Get One
exports.edit = (req, res, next) => {
    const blogId = req.params.id
    Blog
        .findByPk(blogId, {
            // attributes: ['id', 'title', 'imageUrl', 'description'],
            include: [{
                model: User,
                attributes: ['id', 'name', 'email'],
                where: { id: db.Sequelize.col('blog.userId') }
            }]
        })
        .then(blog => {
            if (!blog) {
                return res.status(400).send({
                    message: 'Unable to find blog'
                })
            }

            res.status(200).send({
                blog
            })
        })
        .catch(err => console.log(err))
}

// Update One
exports.update = (req, res, next) => {
    const blogId = req.params.id
    const updatedTitle = req.body.title
    const updatedImageUrl = req.body.imageUrl
    const updatedDesc = req.body.description

    Blog.findByPk(blogId)
        .then(blog => {
            blog.title = updatedTitle
            blog.imageUrl = updatedImageUrl
            blog.description = updatedDesc
            return blog.save()
        })
        .then(result => {
            res.status(200).send({
                message: 'Blog updated successfully'
            })
        })
        .catch(err => console.log(err))
}

// Delete One
exports.delete = (req, res, next) => {
    const blogId = req.params.id

    Blog
        .findByPk(blogId)
        .then(blog => {
            return blog.destroy()
        })
        .then(result => {
            res.status(200).send({
                message: 'Blog deleted successfully'
            })
        })
        .catch(err => console.log(err))
}

// ------------------------- ADMIN ---------------------------------------------------------------
// Get with pagination, filetrs, sort etc
exports.adminBlogs = async (req, res, next) => {
    const limit = 2
    let offset = 0

    try {
        // console.log('Query: ', req.query.order) // Query:  [ 'id:ASC', 'title:DESC' ]
        let orderByData = req.query.order
        let searchBy = req.query.search

        // where: {
        //     // title: {
        //     //     [Op.like]: '%React%'
        //     // }
        // }

        //let whereCondition = { where: {} }
        let whereCondition = {}
        if (searchBy) {
            whereCondition = {
                // where: {
                //     // title: { [Op.like]: `%${searchBy}%` }
                //     title: db.Sequelize.where(db.Sequelize.fn('LOWER', db.Sequelize.col('title')), 'LIKE', '%' + searchBy + '%')
                // }
                title: db.Sequelize.where(db.Sequelize.fn('LOWER', db.Sequelize.col('title')), 'LIKE', '%' + searchBy + '%')
            }
        }

        //&order=title:ASC&order=id:DESC&order=title:DESC

        let orderBy = [
            // ['updatedAt', 'DESC']
        ]
        if (Array.isArray(orderByData) && orderByData.length) {
            orderByData.map((rawSet) => {
                orderBy.push([rawSet.split(':')[0], rawSet.split(':')[1]])
            })
        } else {
            if (orderByData) {
                orderBy.push(orderByData.split(':'))
            }
        }

        const result = await Blog.findAndCountAll({
            // where: {
            //     // title: {
            //     //     [Op.like]: '%React%'
            //     // }
            // }
            where: whereCondition
        })

        const page = req.query.page || 1
        const pages = Math.ceil(result.count / limit)
        offset = limit * (page - 1)

        const blogs = await Blog.findAll({
            // attributes: ['id', 'title', 'imageUrl', 'description'],
            include: [{
                model: User,
                attributes: ['id', 'name', 'email'],
                where: { id: db.Sequelize.col('blog.userId') }
            }],
            where: whereCondition
            // title: db.Sequelize.where(db.Sequelize.fn('LOWER', db.Sequelize.col('title')), 'LIKE', '%' + searchBy + '%')
            ,
            // whereCondition,
            // where: {
            //     // Failes sometimes
            //     // title: {
            //     //     [Op.like]: '%React%'
            //     // }

            //     // working way
            //     //title: db.Sequelize.where(db.Sequelize.fn('LOWER', db.Sequelize.col('title')), 'LIKE', '%' + searchBy + '%')
            // },
            limit,
            offset,
            order: orderBy,
        })
        res.status(200).send({
            blogs,
            count: result.count,
            pages
        })
    } catch (err) {
        console.log(err)
    }
}
