const { authJwt } = require('../middlewares')
const controller = require('../controllers/blog.controller')
const db = require('../models')

module.exports = function (app) {
  app.use(function (req, res, next) {
    res.header(
      'Access-Control-Allow-Headers',
      'x-access-token, Origin, Content-Type, Accept'
    )
    next()
  })

  // Create
  app.post(
    '/api/blog/add',
    [authJwt.verifyToken],
    controller.add
  )

  // Read All
  app.get(
    '/api/blog',
    controller.blog
  )

  // Read One
  app.get(
    '/api/blog/edit/:id',
    // [authJwt.verifyToken],
    controller.edit
  )

  // Update
  app.put(
    '/api/blog/edit/:id',
    [authJwt.verifyToken],
    controller.update
  )

  // Delete
  app.delete(
    '/api/blog/delete/:id',
    [authJwt.verifyToken],
    controller.delete
  )

  // Admin Read All with Pagination, Sort, Filter etc...
  app.get('/api/admin/blogs',
    [authJwt.verifyToken],
    controller.adminBlogs
  )
}
