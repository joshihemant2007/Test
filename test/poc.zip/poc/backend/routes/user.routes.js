const { authJwt } = require('../middlewares')
const controller = require('../controllers/user.controller')
const multer = require('multer')
const sharp = require('sharp')

module.exports = function (app) {
  app.use(function (req, res, next) {
    res.header(
      'Access-Control-Allow-Headers',
      'x-access-token, Origin, Content-Type, Accept'
    )
    next()
  })

  app.get('/api/test/all', controller.allAccess)

  app.get(
    '/api/test/user',
    [authJwt.verifyToken],
    controller.userBoard
  )

  app.get(
    '/api/test/mod',
    [authJwt.verifyToken, authJwt.isBlogger],
    controller.bloggerBoard
  )

  app.get(
    '/api/test/admin',
    [authJwt.verifyToken, authJwt.isAdmin],
    controller.adminBoard
  )

  app.get(
    '/api/get/profile/:id',
    [authJwt.verifyToken],
    controller.getProfileById
  )

  // const multerConfig = {
  //   //specify diskStorage (another option is memory)
  //   storage: multer.diskStorage({
  //     //specify destination
  //     destination: function (req, file, next) {
  //       next(null, './public/images/avatars')
  //     },

  //     //specify the filename to be unique
  //     filename: function (req, file, next) {
  //       console.log('multerConfig: ', file)
  //       const ext = file.mimetype.split('/')[1]
  //       //set the file fieldname to a unique name containing the original name, current datetime and the extension.
  //       next(null, file.fieldname + '-' + Date.now() + '.' + ext)
  //     }
  //   }),

  //   // filter out and prevent non-image files.
  //   fileFilter: function (req, file, next) {
  //     if (!file) {
  //       next()
  //     }
  //     // only permit zip mimetypes
  //     const zip = file.mimetype.startsWith('application')
  //     if (zip) {
  //       console.log('zip uploaded')
  //       next(null, true)
  //     } else {
  //       console.log("file not supported")
  //       errorReq = true
  //       return next()
  //     }
  //   }
  // }

  // Uplaod Profile Avatar
  const uploadAvatar = multer({
    //dest: 'avatars', // by removing dest property, multer is not saving image in avatars directory instead it passess data to /api/update/profile route and then comes in postUpdateProfile controller
    //specify diskStorage (another option is memory)
    storage: multer.diskStorage({
      //specify destination
      destination: function (req, file, next) {
        next(null, './public/images/avatars')
      },

      //specify the filename to be unique
      filename: function (req, file, next) {
        // console.log('uploadAvatar: ', file)

        // Below also working
        // const ext = file.mimetype.split('/')[1]
        //set the file fieldname to a unique name containing the original name, current datetime and the extension.
        // next(null, file.fieldname + '-' + Date.now() + '.' + ext)

        const renamedFileName = new Date().toISOString() + '-' + file.originalname
        const renamedFilePath = './public/images/avatars' + '/' + renamedFileName
        req.body.renamedFileName = renamedFileName
        req.body.renamedFilePath = renamedFilePath

        next(null, renamedFileName)
      }
    }),

    limits: {
      fileSize: 25000000, // 25 mega byte (MB)
    },
    fileFilter(req, file, cb) {
      // On Multer API, we get all values and details
      // file.mimetype === 'image/png' || file.mimetype === 'image/jpg' .....
      // if (!file.originalname.endsWith('.pdf')) {
      if (!file.originalname.match(/\.(jpg|jpeg|png)$/)) { // accept only jpg|jpeg|png
        // const error = new Error('Please upload a jpg or jpeg or png file')
        // // throw error
        // next( error)
        return cb('Please upload a jpg or jpeg or png file')
      }

      cb(undefined, true)

      // cb(new Error('File must be a PDF')) // error
      // cb(undefined, true) // nothing went wrong
      // cb(undefined, false) //
    }
  })

  // Resizer/ cropper using sharp
  const resizeImages = async (req, res, next) => {

    try {
      if (!req.file) return next()

      const renamedFileName = req.body.renamedFileName // we pass this from uploadAvatar middleware
      const avatar = req.file

      let width = height = 250

      const filePath =  './' + avatar.path // avatar.destination + '/' + avatar.filename //path.join(__dirname + '../' + avatar);
      const resizedFileName = `thumb_${height}_${width}_${renamedFileName}` // avatar.originalname  //'cropped_output_' + height + '_' + width + '.jpg';
      const resizedFilePath = avatar.destination + '/' + resizedFileName  //__dirname + '../public/' + outputImageName;

      const ImageResult = await sharp(filePath)
      .resize(height, width)
      .toFile(resizedFilePath)

      req.body.resizedFilePath = resizedFilePath
      return next()
    } catch (err) {
      console.log(err)
    }
  }

  app.post(
    '/api/update/profile',
    [authJwt.verifyToken],
    uploadAvatar.single('streamfileAvatar'), // this 'streamfileAvatar' name should match with react data.append('streamfileAvatar') name
    // multer(multerConfig).single('streamfileAvatar'), // this 'streamfileAvatar' name should match with react data.append('streamfileAvatar') name
    resizeImages, // another middleware to crop images after saving to dir
    controller.postUpdateProfile,
    (error, req, res, next) => { // handling erros from middleware
      res.status(400).send({message: error})
    }
  )
}
