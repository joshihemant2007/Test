export function addStory(story) {
    return {
        type: 'ADD_STORY',
        payload: story
    }
}

export function deleteStory(Id) {
    return {
        type: 'DELETE_STORY',
        payload: Id
    }
}

export function updateStory(story) {
    return {
        type: 'UPDATE_STORY',
        payload: story
    }

}