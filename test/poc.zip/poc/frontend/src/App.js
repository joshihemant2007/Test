import React, { useState } from 'react'
import './App.css'
import "bootstrap/dist/css/bootstrap.min.css"

import { withRouter } from 'react-router-dom'

import ThemeContext from './components/Context/ThemeContext'

import Navbar from './components/Layout/Navbar'

function App() {
  const themeHook = useState('light')

  return (
    <ThemeContext.Provider value={themeHook}>
      <div className="App_renamed">
        <Navbar themeHook={themeHook} />
      </div>
    </ThemeContext.Provider>
  )
}

export default withRouter(App)
