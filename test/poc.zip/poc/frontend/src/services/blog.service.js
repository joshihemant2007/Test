import axios from 'axios'
import authHeader from './auth-header'

// const API_URL = 'http://localhost:8080/api/'

const instance = axios.create({
    baseURL: 'http://localhost:8080/api/',
    // headers: {
        // 'content-type':'application/octet-stream',
        // 'x-rapidapi-host':'example.com',
        // 'x-rapidapi-key': process.env.RAPIDAPI_KEY
    // },
});

class Blogservice {

    // Get All
    getBlogs() {
        return instance.get('blog')
    }

    // Get One
    getBlog(id) {
        return instance.get('blog/edit/' + id, {
            headers: authHeader(),
        })
    }

    // Create
    addBlog(newBlog) {
        return instance.post('blog/add', newBlog, {
            headers: authHeader(),
        })
    }

    // Update
    updateBlog(id, updatedBlog) {
        return instance.put('blog/edit/' + id, updatedBlog, {
            headers: authHeader(),
        })
    }

    // Delete
    deleteBlog(id) {
        return instance.delete('blog/delete/' + id, {
            headers: authHeader(),
        })
    }

    // ----------------------------- ADMIN ---------------------------------
    getAdminBlogs(currentPage, orderByQueryString, searchLikeQueryString) {
        // '&order=id:DESC&order=title:DESC'
        return instance.get('admin/blogs?page=' + currentPage + orderByQueryString + searchLikeQueryString, {
            headers: authHeader()
        })
    }
}

export default new Blogservice()