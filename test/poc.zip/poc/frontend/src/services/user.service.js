import axios from 'axios'
import authHeader from './auth-header'

const API_URL = 'http://localhost:8080/api/'

class UserService {

    getProfile(uid) {
        return axios.get(API_URL + 'get/profile/' + uid, { headers: authHeader() })
    }

    getPublicContent() {
        return axios.get(API_URL + 'test/all')
    }

    getUserBoard() {
        return axios.get(API_URL + 'test/user', { headers: authHeader() })
    }

    getBloggerBoard() {
        return axios.get(API_URL + 'test/mod', { headers: authHeader() })
    }

    getAdminBoard() {
        return axios.get(API_URL + 'test/admin', { headers: authHeader() })
    }

    postUpdateProfile(formData) {
        // console.log('postUpdateProfile: ' + formData)
        return axios.post(API_URL + 'update/profile', formData, {
            headers: authHeader(),
        })
    }
}

export default new UserService()