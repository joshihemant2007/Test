import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';

import { BrowserRouter } from 'react-router-dom'

import { createStore } from 'redux';
import { Provider } from 'react-redux'
import storyReducer from './reducers/storyReducer';

let initialState = [
  { id: 1, title: 'First Blog Redux', desc: 'First blog desc' },
  { id: 2, title: 'Second Blog Redux', desc: 'Second blog desc' },
  { id: 3, title: 'Third Blog Redux', desc: 'Third blog desc' },
  { id: 4, title: 'Forth Blog Redux', desc: 'Forth blog desc' }
]

if (localStorage.getItem('stories') === null)
  localStorage.setItem('stories', JSON.stringify(initialState));
else
  initialState = JSON.parse(localStorage.getItem('stories'));

const store = createStore(storyReducer, initialState);

ReactDOM.render(
  <> {/* <React.StrictMode> */}
    <BrowserRouter><Provider store={store}><App /></Provider></BrowserRouter>
  </>/* </React.StrictMode> */,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
