import React, { Fragment } from 'react'
import { Switch, Route, NavLink, withRouter } from 'react-router-dom'

import ThemeContext from '../Context/ThemeContext'
import AppTheme from '../Context/Colors'
import ThemeToggler from '../Context/ThemeToggler'

import About from '../Pages/About'
import Contact from '../Pages/Contact'
import Login from '../SignIn'
import SignUp from '../SignUp'
import SearchBar from './SearchBar'
import Blogs from '../Blog/Blogs'
// import AddBlog from '../Blog/AddBlog'
// import Profile from '../User/Tabs/Profile'
import Account from '../User/Layout/Account';
// import Dashboard from '../User/Tabs/Dashboard';
// import Message from '../User/Tabs/Message';
import BlogDetails from '../Blog/BlogDetails'

import AuthService from '../../services/auth.service'

class Navbar extends React.Component {

    constructor(props) {
        super(props)

        const user = AuthService.getCurrentUser()
        let tmpState = {}

        if (user) {
            tmpState = {
                blogs: [],
                currentUser: user,
                showBloggerProfile: user.roles.includes("ROLE_BLOGGER"),
                showAdminProfile: user.roles.includes("ROLE_ADMIN"),
                search: null
            }
        } else {
            tmpState = {
                blogs: [],
                currentUser: undefined,
                showBloggerProfile: false,
                showAdminProfile: false,
                search: null
            }
        }

        this.state = tmpState
    }

    logoutHandler = () => {
        AuthService.logout()
        this.setState({
            currentUser: undefined,
            showBloggerProfile: false,
            showAdminProfile: false,
        })
    }

    componentDidUpdate() {
        document.body.style.backgroundColor = (this.props.themeHook[0] === 'light' ? '#FFF' : '#ccc')
    }

    searchHandler = (e, searchStr) => {
        e.preventDefault()

        if (this.props.location != '/') {
            this.props.history.push('/');
        }

        this.setState({
            search: searchStr
        })
    }

    render() {

        let routes =
            <Switch>
                <Route path="/about" exact component={About} />
                <Route path="/contact" exact component={Contact} />
                <Route path="/login" exact component={() => <Login  {...this.props} />} />
                <Route path="/register" exact component={() => <SignUp {...this.props} />} />
                {/* <Route path="/add-blog" exact component={() => <AddBlog {...this.props} />} /> */}
                {/* <Route path="/blog/edit/:id" exact component={() => <AddBlog {...this.props} />} /> */}
                <Route path="/blog/view/:id" exact component={BlogDetails} />
                <Route path="/" exact component={() => <Blogs {...this.props} search={this.state.search} user={this.state.currentUser} />} />
                <Route path="/account" component={() => <Account {...this.props} />} />
            </Switch>

        const { currentUser, showBloggerProfile, showAdminProfile } = this.state

        return (
            // Consume context from class component II (I is from BlogItem)
            <ThemeContext.Consumer>
                {
                    (theme) => {
                        const currentTheme = AppTheme[theme[0]];

                        return (
                            <Fragment>
                                <nav className={"navbar navbar-expand-lg sticky-top " + currentTheme}> {/* navbar-light bg-light */}
                                    <a className="navbar-brand" href="/"><img src="https://www.pikpng.com/pngl/m/204-2041643_boss-logo-icon-02-react-logo-small-clipart.png" width="30" height="30" className="d-inline-block align-top" alt="" />BLOGER</a>
                                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                        <span className="navbar-toggler-icon"></span>
                                    </button>

                                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                                        <ul className="navbar-nav mr-auto">
                                            <li className="nav-item"><NavLink className="nav-link" to="/" exact>Blog</NavLink></li>
                                            <li className="nav-item"><NavLink className="nav-link" to="/about" exact>About</NavLink></li>
                                            <li className="nav-item"><NavLink className="nav-link" to="/contact" exact>Contact</NavLink></li>

                                            {/* {
                                                currentUser && (showBloggerProfile || showAdminProfile) ?
                                                    <li className="nav-item"><NavLink className="nav-link" to="/add-blog" exact>Add Blog</NavLink></li>
                                                    : null
                                            } */}
                                            {currentUser ?
                                                (
                                                    <Fragment>
                                                        {/* {<li className="nav-item"><NavLink className="nav-link" to="/profile" exact>Profile</NavLink></li>} */}
                                                        <li className="nav-item"><NavLink className="nav-link" to="/account">Account</NavLink></li>
                                                        <li className="nav-item"><NavLink className="nav-link" to="/logout" exact onClick={this.logoutHandler}>Logout</NavLink></li>
                                                    </Fragment>
                                                )
                                                : (
                                                    <Fragment>
                                                        <li className="nav-item"><NavLink className="nav-link" to="/login" exact>Signin</NavLink></li>
                                                        <li className="nav-item"><NavLink className="nav-link" to="/register" exact>Signup</NavLink></li>
                                                    </Fragment>
                                                )
                                            }
                                        </ul>

                                        <SearchBar onSearch={this.searchHandler}/>

                                        <ThemeToggler />
                                    </div>
                                </nav>

                                {routes}
                            </Fragment>
                        )
                    }
                }
            </ThemeContext.Consumer>
        )
    }
}

export default withRouter(Navbar)
