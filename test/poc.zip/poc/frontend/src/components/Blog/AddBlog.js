import React, { Component } from 'react'

import { matchPath } from 'react-router'

import Form from 'react-validation/build/form'
import Input from 'react-validation/build/input'
import CheckButton from 'react-validation/build/button'

import BlogService from '../../services/blog.service'
import Spinner from '../Ui/Spinner';

const required = value => {
    if (!value) {
        return (
            <div className="alert alert-danger" role="alert">
                This field is required!
            </div>
        )
    }
}

const vtitle = value => {
    if (value.length < 3 || value.length > 250) {
        return (
            <div className="alert alert-danger" role="alert">
                The name must be between 3 and 250 characters.
            </div>
        )
    }
}

class AddBlog extends Component {
    constructor(props) {
        super(props)

        this.match = matchPath(this.props.history.location.pathname, {
            path: '/account/blog/edit/:id',
            exact: true,
            strict: false
        })

        this.state = {
            title: '',
            imageUrl: '',
            description: '',
            isEdit: false,
            editId: null,
            formLoading: true,
            loading: false,
            successful: false,
            message: ''
        }
    }

    componentDidMount() {
        if (this.match) {
            const { id } = this.match.params

            this.setState ({
                editId: id
            })

            BlogService
                .getBlog(id)
                .then(response => {
                    let { title, imageUrl, description } = response.data.blog

                    this.setState({
                        title,
                        imageUrl,
                        description,
                        isEdit: true,
                        loading: false,
                        successful: true,
                        message: response.data.message
                    })
                })
                .catch(error => {
                    console.log(error)
                    const resMessage =
                        (error.response &&
                            error.response.data &&
                            error.response.data.message) ||
                        error.message ||
                        error.toString();

                    this.setState({
                        loading: false,
                        message: resMessage
                    })
                })
        }

        this.setState({
            formLoading: false
        })
    }

    onChangeHandler = (e) => {
        let { name, value } = e.target

        this.setState({
            [name]: value
        })
    }

    onSubmitHandler = (e) => {
        e.preventDefault()

        this.setState({
            loading: true,
            successful: false,
            message: ''
        })

        this.form.validateAll()

        if (this.checkBtn.context._errors.length === 0) {
            let { title, imageUrl, description, isEdit, editId } = this.state

            let blogPost
            if (isEdit) {
                blogPost = { title, imageUrl, description }

                BlogService
                    .updateBlog(editId, blogPost)
                    .then(response => {
                        this.setState({
                            title: '',
                            imageUrl: '',
                            description: '',
                            loading: false,
                            successful: true,
                            message: response.data.message
                        })

                        this.props.history.push('/');
                    })
                    .catch(error => {
                        const resMessage =
                            (error.response &&
                                error.response.data &&
                                error.response.data.message) ||
                            error.message ||
                            error.toString();

                        this.setState({
                            loading: false,
                            message: resMessage
                        })
                    })
            }
            else {
                blogPost = { id: null, title, imageUrl, description }

                BlogService
                    .addBlog(blogPost)
                    .then(response => {
                        // window.location.reload();
                        this.props.history.push('/')
                        this.setState({
                            title: '',
                            imageUrl: '',
                            description: '',
                            loading: false,
                            successful: true,
                            message: response.data.message
                        })
                    })
                    .catch(error => {
                        const resMessage =
                            (error.response &&
                                error.response.data &&
                                error.response.data.message) ||
                            error.message ||
                            error.toString();

                        this.setState({
                            loading: false,
                            message: resMessage
                        })
                    })
            }


        } else {
            this.setState({
                loading: false,
                message: ''
            })
        }
    }

    render() {

        let { title, imageUrl, description } = this.state

        return (
            <div className="container">
                <p></p>
                <div className="container-fluid h-100">
                    <div className="row justify-content-center align-items-center h-100">
                        <div className="col col-sm-6 col-md-6 col-lg-4 col-xl-5">
                            {
                                this.state.formLoading ? (<Spinner />) : (
                                    <Form
                                        onSubmit={this.onSubmitHandler}
                                        ref={c => {
                                            this.form = c
                                        }}
                                    >
                                        <div className="form-group">
                                            <Input
                                                _ngcontent-c0=""
                                                className="form-control"
                                                placeholder="Title*"
                                                type="text"
                                                name="title"
                                                value={title}
                                                onChange={this.onChangeHandler}
                                                validations={[required, vtitle]} />
                                        </div>
                                        <div className="form-group">
                                            <input
                                                className="form-control"
                                                placeholder="Image Url"
                                                type="text"
                                                name="imageUrl"
                                                value={imageUrl}
                                                onChange={this.onChangeHandler}
                                            />
                                        </div>
                                        <div className="form-group">
                                            <textarea className="form-control" placeholder="Description" rows="5" id="description" name="description" onChange={this.onChangeHandler} value={description}></textarea>
                                        </div>
                                        <div className="form-group row">
                                            <div className="col-sm-10">
                                                <button
                                                    className="btn btn-primary"
                                                    type="submit"
                                                    disabled={this.state.loading}
                                                >
                                                    {
                                                        this.state.loading && (
                                                            <span className="spinner-border spinner-border-sm"></span>
                                                        )
                                                    }
                                                    {this.state.isEdit ? 'Update' : 'Add'} Blog
                                                </button>
                                            </div>
                                        </div>

                                        {this.state.message && (
                                            <div className="form-group">
                                                <div
                                                    className={
                                                        this.state.successful
                                                            ? "alert alert-success"
                                                            : "alert alert-danger"
                                                    }
                                                    role="alert"
                                                >
                                                    {this.state.message}
                                                </div>
                                            </div>
                                        )}

                                        <CheckButton
                                            style={{ display: "none" }}
                                            ref={d => {
                                                this.checkBtn = d
                                            }}
                                        />
                                    </Form>
                                )
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default AddBlog
