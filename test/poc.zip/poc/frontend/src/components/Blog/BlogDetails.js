import React, { useState, useEffect, Fragment } from 'react'

import BlogService from '../../services/blog.service'
import Spinner from '../Ui/Spinner';

import PrintPdfButton from '../Pdf/PrintPdfButton'

const BlogDetails = (props) => {
    const [loaded, setLoaded] = useState(false)
    const [title, setTitle] = useState(null)
    let [imageUrl, setImageUrl] = useState(null)
    const [description, setDescription] = useState(null)
    const [owner, setOwner] = useState('')

    useEffect(() => {
        const { id } = props.match.params

        BlogService
            .getBlog(id)
            .then(result => {
                const { title, imageUrl, description, user } = result.data.blog
                setTitle(title)
                setImageUrl(imageUrl)
                setDescription(description)
                setLoaded(true)
                setOwner(user.name)
            })
            .catch(err => console.log(err))
    }, [])

    if (!imageUrl) {
        imageUrl = 'https://res.cloudinary.com/blogpedia/image/upload/default.png'
    }

    return (
        <div>
            {
                !loaded ? <Spinner /> :
                    (
                        <Fragment>
                            <PrintPdfButton
                                label="Print to Pdf"
                                id="blog-details"
                                pdfName={ title ? `blog-` + title.split(' ').join('-') : `blog` }
                            />
                            <div className="row" id="blog-details">
                                <div className="col-5 shadow-lg p-3 mb-5 bg-white rounded" style={{ marginLeft: '10px' }}>
                                    <figure className="figure">
                                        <img src={imageUrl} className="figure-img img-fluid rounded" style={{ maxWidth: '100%', height: 'auto' }} alt={title} />
                                        <figcaption className="figure-caption text-right">Posted By - {owner}</figcaption>
                                    </figure>
                                </div>
                                <div className="col-6">
                                    <p></p>
                                    <h2 className="card-title text-uppercase font-weight-bold">{title}</h2>
                                    <hr style={{ borderTop: '7px solid #17a2b8' }}></hr>
                                    <h5 className="card-title font-weight-normal">{description}</h5>
                                </div>
                            </div>
                        </Fragment>
                    )
            }
        </div>
    )
}

export default BlogDetails
