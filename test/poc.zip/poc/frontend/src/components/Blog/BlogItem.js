import React, { Component, Fragment } from 'react'

import BlogService from '../../services/blog.service'
import ThemeContext from "../Context/ThemeContext";

class BlogItem extends Component {

    onViewHandler = (id) => {
        this.props.history.push('blog/view/' + id)
    }

    onEditHandler = (id) => {
        this.props.history.push('/account/blog/edit/' + id)
    }

    onDeleteHandler = (id) => {
        BlogService
            .deleteBlog(id)
            .then(response => {
                this.props.history.push('/')
            })
            .catch(error => {
                console.log(error)
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                this.setState({
                    loading: false,
                    message: resMessage
                })
            })
    }

    // Consume context from class component I
    static contextType = ThemeContext;

    render() {
        // console.log(this.context); // light/dark
        let { id, title = '', imageUrl = 'https://res.cloudinary.com/blogpedia/image/upload/default.png', description = '' } = this.props.blogPost

        if (!imageUrl) {
            imageUrl = 'https://res.cloudinary.com/blogpedia/image/upload/default.png'
        }

        return (
            <div className="card"> {/* col-sm-4  */}
                <img src={imageUrl} className="card-img-top" alt={title} />
                <div className="card-body shadow-lg p-3 bg-white rounded">
                    <h5 className="card-title text-uppercase font-weight-bold">{title}</h5>
                    <p className="card-text text-truncate" style={{ maxWidth: '350px' }}>{description}</p>
                    <p className="card-text">
                        <small className="text-muted">By - {this.props.blogPost.user.name ? this.props.blogPost.user.name : 'Anonymous'}</small>
                        <ul className="list-inline m-0">
                            <li className="list-inline-item">
                                <a href="javascript: void(0)" onClick={(e) => this.onViewHandler(this.props.blogPost.id)} className="badge badge-info">Read</a>
                            </li>
                            {
                                this.props.user && (this.props.blogPost.user.id === this.props.user.id) ?
                                    <Fragment>
                                        <li className="list-inline-item">
                                            <a href="javascript: void(0)" onClick={(e) => this.onEditHandler(this.props.blogPost.id)} className="badge badge-success">Edit</a>
                                        </li>
                                        <li className="list-inline-item">
                                            <a href="javascript: void(0)" onClick={(e) => this.onDeleteHandler(this.props.blogPost.id)} className="badge badge-danger">Delete</a>
                                        </li>
                                    </Fragment>
                                    : null
                            }
                        </ul>
                    </p>
                </div>
            </div>
        )
    }
}

export default BlogItem
