import React from 'react'
import BlogItem from './BlogItem'

import BlogService from '../../services/blog.service'
import Spinner from '../Ui/Spinner';

class Blogs extends React.Component {

    state = {
        blogs: {},
        loading: true
    }

    componentDidMount() {
        BlogService
            .getBlogs()
            .then(response => {
                this.setState({
                    blogs: response.data.blogs,
                    loading: false,
                })
            })
            .catch(error => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                this.setState({
                    loading: false,
                    message: resMessage
                })
            })
    }

    render() {
        let blogs = this.state.loading ? <Spinner /> : null
        let blogsPosts = this.state.blogs

        let isSearched = false;
        if (blogsPosts.length) {
            if (this.props.search) {
                isSearched = true
                blogsPosts = blogsPosts.filter(blog => {
                    return (
                        blog.title.toLowerCase().includes(this.props.search.toLowerCase())
                    )
                })
            }

            let blogData = blogsPosts.map(blog => {
                return <BlogItem {...this.props} key={blog.id} blogPost={blog} />
            })

            // if (this.props.search && !blogsPosts.length) {
            //     blogs = <div className="card-columns">sadsadsd</div>
            // } else {
            blogs = <div className="card-columns">{blogData}</div>
            // }
        }

        if (!isSearched) {
            if (!this.state.loading && !blogsPosts.length) {
                blogs = <p className="no-content">No blogs found</p>
            }
        } else {
            if (!this.state.loading && !blogsPosts.length) {
                blogs = <p className="no-content">Please change search filter</p>
            }
        }

        return (
            <div className="container">
                <p></p>
                {/* {display: flex, flex-wrap: wrap } */}
                {/* <BlogItem /> also fo rcard-column add row */}
                {blogs}
            </div>
        )
    }
}

export default Blogs;
