import React, { Component, Fragment } from 'react'

class StoryItem extends Component {
    constructor(props) {
        super(props)
        this.state = { isEdit: false }
        // this.editStory = this.editStory.bind(this)
        // this.editStorySubmit = this.editStorySubmit.bind(this)
        // this.deleteStory = this.deleteStory.bind(this)
    }
    deleteStory = () => {
        let { id } = this.props.story
        this.props.deleteStory(id)
    }
    editStory = () => {
        this.setState((prevState, props) => ({
            isEdit: !prevState.isEdit
        }))
    }
    editStorySubmit = () => {
        const { id } = this.props.story

        this.props.editStorySubmit(
            id,
            this.titleInput.value,
            this.descInput.value,
        )

        this.setState((prevState, props) => ({
            isEdit: !prevState.isEdit
        }))
    }

    render() {
        const { id, title, desc } = this.props.story
        return (
            this.state.isEdit === true ? (
                <tr className="bg-warning" key={this.props.index}>
                    <td>
                        <input ref={titleInput => this.titleInput = titleInput} defaultValue={title} />
                    </td>
                    <td><textarea defaultValue={desc} ref={descInput => this.descInput = descInput}></textarea>
                    </td>
                    <td><a className="far fa-save" onClick={() => this.editStorySubmit()}>Save</a></td>
                    <td><a className="fas fa-trash" onClick={() => this.deleteStory()}>Delete</a></td>
                </tr>
            ) : (
                    <tr key={this.props.index}>
                        <td>{id}</td>
                        <td>{title}</td>
                        <td>{desc}</td>
                        <td><a className="far fa-edit" onClick={() => this.editStory()}>Edit</a></td>
                        <td><a className="fas fa-trash" onClick={() => this.deleteStory()}>Delete</a></td>
                    </tr>
                )
        )
    }
}

export default StoryItem
