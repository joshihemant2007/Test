import React, { Component, Fragment } from 'react'

import StoryItem from './StoryItem'

class StoryList extends Component {

    render() {
        console.log(this.props)
        let trItem = this.props.stories.map((item, index) => (
            <StoryItem
                key={index}
                story={item}
                index={index}
                editStorySubmit={this.props.editStorySubmit}
                deleteStory={this.props.deleteStory}
            />
        ))

        return (
            trItem
        )
    }
}

export default StoryList
