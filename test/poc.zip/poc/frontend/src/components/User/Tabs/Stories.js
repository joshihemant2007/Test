import React, { Component, Fragment } from 'react'

import Spinner from '../../Ui/Spinner'
import StoryList from './StoryList.js'

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { addStory, deleteStory, updateStory } from '../../../actions/storyActions'

// const storiesData = [
//     { id: 1, title: 'FIRST', desc: '1st story desc' },
//     { id: 2, title: 'SECOND', desc: '2nd story desc' },
//     { id: 3, title: 'THIRD', desc: '3rd story desc' },
//     { id: 4, title: 'FORTH', desc: '4th story desc' }
// ];

// if (localStorage.getItem('stories') === null) {
//     localStorage.setItem('stories', JSON.stringify(storiesData));
// }

class Stories extends Component {

    constructor(props) {
        super(props)

        // this.state = {
        //     stories: [],
        //     isLoading: false
        // }
    }

    // componentDidMount() {
    //     let stories = JSON.parse(localStorage.getItem('stories'))
    //     //console.log('dasdsad', stories)
    //     this.setState((prevState, props) => ({
    //         stories: stories
    //     }))
    // }

    addNewStory = () => {
        this.props.addStory({
            id: Math.max(...this.props.stories.map(function (o) { return o.id })) + 1,
            title: 'From redux',
            desc: 'From redux description'
        })

        // this.setState((prevState, props) => ({
        //     stories: [...prevState.stories, {
        //         id: Math.max(...prevState.stories.map(function (o) {
        //             return o.id
        //         })) + 1,
        //         title: '',
        //         desc: '',
        //     }]
        // }));
    }

    deleteStory = (id) => {
        let r = window.confirm("Do you want to delete this item");
        if (r === true) {
            this.props.deleteStory(id);

            // let filteredStory = this.state.stories.filter(
            //     x => x.id !== id
            // );
            // this.setState((prevState, props) => ({
            //     stories: filteredStory
            // }));
            // localStorage.setItem(
            //     'stories',
            //     JSON.stringify(filteredStory)
            // );
        }
    }

    editStorySubmit = (id, title, desc) => {
        this.props.updateStory({ id: id, title: title, desc: desc });

        // let storyCopy = this.state.stories.map((story) => {
        //     if (story.id === id) {
        //         story.title = title;
        //         story.desc = desc;
        //     }
        //     return story;
        // });

        // localStorage.setItem(
        //     'stories',
        //     JSON.stringify(storyCopy)
        // );

        // this.setState((prevState, props) => ({
        //     stories: storyCopy
        // }));
    }

    orderByHandler = (col) => {

    }

    render() {
        return (
            <div className="tab-pane text-center show active" id="v-pills-stories" role="tabpanel" aria-labelledby="v-pills-stories-tab">
                {
                    //this.state.isLoading ? <Spinner /> :
                        (
                            <Fragment>
                                {
                                    // !totalPages ? null :
                                    // <Paginator
                                    //     onPagination={paginationClickHander}
                                    //     currentPage={currentPage}
                                    //     totalPages={totalPages}
                                    //     previousDisabled={currentPage <= 1 ? 'disabled' : ''}
                                    //     nextDisabled={currentPage >= totalPages ? 'disabled' : ''}
                                    //     enableSearch="true"
                                    //     onSearch={searchHandler}
                                    //     searchStr={search}
                                    // />
                                }
                                <table className="bd-browser-bugs table table-bordered table-hover">
                                    <thead>
                                        <tr className="table">
                                            <th scope="col"><a onClick={() => this.orderByHandler('id')}>#</a></th>
                                            <th scope="col"><a onClick={() => this.orderByHandler('title')}>Title</a></th>
                                            <th scope="col">Description</th>
                                            <th scope="col" colSpan='2'>Action</th>
                                        </tr>
                                    </thead>
                                    <StoryList deleteStory={this.deleteStory} stories={this.props.stories} editStorySubmit={this.editStorySubmit} />

                                    {/* <tbody>
                                        <StoryList
                                            deleteStory={this.deleteStory}
                                            stories={this.state.stories}
                                            editStorySubmit={this.editStorySubmit}
                                        />
                                    </tbody> */}
                                </table>
                                <button
                                    className="btn btn-dark pull-left"
                                    onClick={this.addNewStory}>
                                    Add New
                                </button>
                            </Fragment>
                        )
                }
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        stories: state
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators({
        addStory: addStory,
        deleteStory: deleteStory,
        updateStory: updateStory
    }, dispatch);
}

export default connect(mapStateToProps,mapDispatchToProps)(Stories)
