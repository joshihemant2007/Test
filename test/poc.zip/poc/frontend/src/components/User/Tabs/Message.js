import React, { Component } from 'react'

class Message extends Component {
    render() {
        return (
            <div className="tab-pane text-center show active" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                Message
            </div>
        )
    }
}

export default Message
