import React, { useState, useEffect, Fragment } from 'react'
import { withRouter } from 'react-router-dom'

import BlogService from '../../../services/blog.service'
import AuthService from '../../../services/auth.service'
import Spinner from '../../Ui/Spinner';
import Paginator from './Paginator';

const Dashboard = (props) => {
    // State
    let [blogs, setBlogs] = useState({})
    const [isLoading, setLoading] = useState(true)
    const [message, setMessage] = useState(false)

    // Pagination
    const [currentPage, setCurrentPage] = useState(1)
    const [totalPages, setTotalPages] = useState(0)

    // Order BY
    const [orderByQuery, setOrderByQuery] = useState([])
    const [orderByQueryString, setOrderByQueryString] = useState('')

    // Search (like)
    const [search, setSearch] = useState('')
    const [searchLikeQueryString, setSearchLikeQueryString] = useState('')

    // Current user
    const [user, setUser] = useState({})
    useEffect(() => {
        const user = AuthService.getCurrentUser()
        setUser(user)
    }, [])

    useEffect(() => {
        setLoading(true)
        BlogService
            .getAdminBlogs(currentPage, orderByQueryString, searchLikeQueryString)
            .then(response => {
                console.log('===', response.data.blogs)
                setBlogs(response.data.blogs)
                setTotalPages(response.data.pages)
                setLoading(false)
            })
            .catch(error => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setMessage(resMessage)
            })
    }, [currentPage, orderByQueryString, searchLikeQueryString])

    const onViewHandler = (id) => {
        props.history.push('/blog/view/' + id)
    }

    const onEditHandler = (id) => {
        props.history.push('/account/blog/edit/' + id)
    }

    const onDeleteHandler = (id) => {
        BlogService
            .deleteBlog(id)
            .then(response => {
                props.history.push('/')
            })
            .catch(error => {
                console.log(error)
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                this.setState({
                    loading: false,
                    message: resMessage
                })
            })
    }

    const searchHandler = (str) => {
        setSearch(str)
        setSearchLikeQueryString(`&search=${str}`)
        setCurrentPage(1)
    }

    const paginationClickHander = (direction) => {
        if (direction === 'next') {
            setCurrentPage(currentPage + 1)
        } else if (direction === 'previous') {
            setCurrentPage(currentPage - 1)
        } else {
            setCurrentPage(direction)
        }
    }

    const orderByHandler = (column) => {
        let foundIndex = orderByQuery.findIndex(c => c.column === column)

        let updatedOrderBy = []
        updatedOrderBy = [...orderByQuery]
        if (foundIndex >= 0) {
            let oldColumnVal = updatedOrderBy[foundIndex]['value']

            updatedOrderBy[foundIndex] = { 'column': column, 'value': oldColumnVal === 'DESC' ? 'ASC' : 'DESC' }
            setOrderByQuery(updatedOrderBy)
        }
        else {
            updatedOrderBy.push({ 'column': column, 'value': 'DESC' })
            setOrderByQuery(updatedOrderBy)
        }

        let updatedOrderByQueryArr = []
        updatedOrderByQueryArr = updatedOrderBy.map(entry => {
            return `&order=${entry.column}:${entry.value}`
        })

        let updatedOrderByQueryString = updatedOrderByQueryArr.join('')
        setOrderByQueryString(updatedOrderByQueryString)
    }

    let blogsPosts = blogs

    let blogRows
    if (blogsPosts.length) {
        blogRows = blogsPosts.map((blog, index) => {

            let imageUrl = blog.imageUrl
            if (!imageUrl) {
                imageUrl = 'https://res.cloudinary.com/blogpedia/image/upload/default.png'
            }

            return (
                <tr key={blog.id} className="table">
                    <th scope="row">{index + 1}</th>
                    <td className="text-left text-justify">{blog.title}</td>
                    <td>
                        <img className="rounded mx-auto d-block img-thumbnail" src={imageUrl} alt={blog.title} />
                    </td>
                    <td className="text-justify">{blog.description}</td>
                    <td className="text-justify">{blog.user.name}</td>
                    <td className="text-justify">{blog.updatedAt.toString()}</td>
                    <td>
                        <table className="table table-sm table-light">
                            <tbody>
                                <tr className="table-secondary">
                                    <th scope="row"><a href="javascript: void(0)" onClick={(e) => onViewHandler(blog.id)} className="badge badge-info">View</a></th>
                                </tr>
                                {
                                    user.id === blog.user.id ?
                                        <Fragment>
                                            <tr className="table-secondary">
                                                <th scope="row"><a href="javascript: void(0)" onClick={(e) => onEditHandler(blog.id)} className="badge badge-success">Edit</a></th>
                                            </tr>
                                            <tr className="table-secondary">
                                                <th scope="row"><a href="javascript: void(0)" onClick={(e) => onDeleteHandler(blog.id)} className="badge badge-danger">Delete</a></th>
                                            </tr>
                                        </Fragment>
                                        : null
                                }

                            </tbody>
                        </table>
                    </td>
                </tr>
            )
        })
    }

    return (

        <div className="tab-pane text-center show active" id="v-pills-dashboard" role="tabpanel" aria-labelledby="v-pills-dashboard-tab">
            {
                isLoading ? <Spinner /> :
                    (
                        <Fragment>
                            {
                                // !totalPages ? null :
                                <Paginator
                                    onPagination={paginationClickHander}
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    previousDisabled={currentPage <= 1 ? 'disabled' : ''}
                                    nextDisabled={currentPage >= totalPages ? 'disabled' : ''}
                                    enableSearch="true"
                                    onSearch={searchHandler}
                                    searchStr={search}
                                />
                            }
                            <table className="bd-browser-bugs table table-bordered table-hover">
                                <thead>
                                    <tr className="table">
                                        <th scope="col"><a href="javascript: void (0)" onClick={() => orderByHandler('id')}>#</a></th>
                                        <th scope="col"><a href="javascript: void (0)" onClick={() => orderByHandler('title')}>Title</a></th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Creator</th>
                                        <th scope="col">Updated At</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {blogRows}
                                </tbody>
                            </table>
                        </Fragment>
                    )
            }
        </div>
    )
}

export default withRouter(Dashboard)
