import React, { useState, useEffect, Fragment } from 'react'

import Spinner from '../../Ui/Spinner'

import AuthService from '../../../services/auth.service'
import UserService from '../../../services/user.service'

import PrintPdfButton from '../../Pdf/PrintPdfButton'

const maxSelectFile = (event) => {
    let files = event.target.files // create file object
    if (files.length > 3) {
        const msg = 'Only 3 images can be uploaded at a time'
        event.target.value = null // discard selected file
        console.log(msg)
        return false;

    }
    return true;
}

const checkFileSize = (event) => {
    let files = event.target.files
    let size = 15000
    let err = "";
    for (var x = 0; x < files.length; x++) {
        if (files[x].size > size) {
            err += files[x].type + 'is too large, please pick a smaller file\n';
        }
    };
    if (err !== '') {
        event.target.value = null
        console.log(err)
        return false
    }

    return true;
}

const Profile = () => {
    const [isProfileLoaded, setProfileLoaded] = useState(false)
    const [userName, setUserName] = useState(null)
    const [userEmail, setUserEmail] = useState(null)
    const [userAvatar, setuserAvatar] = useState(null)
    const [deleteAvatar, setDeleteAvatar] = useState(false)
    const [message, setMessage] = useState(null)

    // Updation states
    const [isEditMode, setEditMode] = useState(false)
    const [username, setUsername] = useState('')
    const [avatar, setAvatar] = useState(null)
    const [curAvatar, setCurAvatar] = useState(null)
    const [isAvatarChanged, setAvatarChanged] = useState(0)

    useEffect(() => {
        const user = AuthService.getCurrentUser()
        if (user) {
            UserService
                .getProfile(user.id)
                .then(result => {
                    // console.log('Result: ', result.data.user)
                    setUserName(result.data.user.name)
                    setUsername(result.data.user.name)
                    setUserEmail(result.data.user.email)
                    setuserAvatar(result.data.user.avatar)
                    if (result.data.user.avatar != '') {
                        setCurAvatar('http://localhost:8080/' + result.data.user.avatar)
                    }
                    setProfileLoaded(true)
                }).catch(err => console.log(err))
        }
    }, [isEditMode])

    const onBrowse = (e) => {
        setAvatarChanged(1)
        setAvatar(e.target.files)
        if (e.target.files[0]) {
            const tmpImg = URL.createObjectURL(e.target.files[0])
            setCurAvatar(tmpImg)
        }
    }

    const submitHandler = (e) => {
        e.preventDefault()
        let data = new FormData()
        data.append('name', username)
        if (deleteAvatar === true) {
            data.append('deleteAvatar', '1')
        } else {
            data.append('deleteAvatar', '0')
        }

        if (avatar && isAvatarChanged === 1) {
            data.append('streamfileAvatar', avatar[0])
        }

        UserService
            .postUpdateProfile(data)
            .then(response => {
                setEditMode(false)
                setAvatarChanged(0)
                setDeleteAvatar(false)
                setCurAvatar(null)
                setMessage(null)
            })
            .catch(error => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setMessage(resMessage)
            })
    }

    return (
        <Fragment>
            <div className="tab-pane show active" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                {
                    isEditMode
                        ?
                        <Fragment>
                            <div className="container">
                                <p></p>
                                <div className="container-fluid h-100">
                                    <div className="row justify-content-center align-items-center h-100">
                                        <div className="col col-sm-6 col-md-6 col-lg-4 col-xl-5">
                                            {
                                                <form onSubmit={submitHandler}>
                                                    <div className="form-group">
                                                        <input
                                                            _ngcontent-c0=""
                                                            className="form-control"
                                                            placeholder="Username"
                                                            type="text"
                                                            name="username"
                                                            value={username}
                                                            onChange={(e) => setUsername(e.target.value)}
                                                        />
                                                    </div>
                                                    <div class="input-group">
                                                        <div class="custom-file">
                                                            <input
                                                                class="custom-file-input"
                                                                id="inputGroupFile04"
                                                                aria-describedby="inputGroupFileAddon04"
                                                                type="file"
                                                                name="avatar"
                                                                // onChange={(e) => setAvatar(e.target.files)}
                                                                onChange={onBrowse}
                                                            />
                                                            <label class="custom-file-label" for="inputGroupFile04">Choose file</label>
                                                        </div>
                                                        <div class="input-group-append">
                                                            {/* <button class="btn btn-outline-secondary" type="button" id="inputGroupFileAddon04">Button</button> */}
                                                        </div>
                                                    </div>

                                                    {
                                                        curAvatar ?
                                                            <Fragment>
                                                                <div className="form-group">
                                                                    <img src={curAvatar} style={{ width: '340px' }} />
                                                                </div>

                                                                <div class="input-group mb-3">
                                                                    <div class="input-group-prepend">
                                                                        <div class="input-group-text">
                                                                            <input
                                                                                aria-label="Checkbox for following text input"
                                                                                type="checkbox"
                                                                                name="delete"
                                                                                checked={deleteAvatar}
                                                                                onChange={() => setDeleteAvatar(!deleteAvatar)}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <input type="text" class="form-control" aria-label="Text input with checkbox" value="Remove Profile Picture" />
                                                                </div>
                                                            </Fragment>
                                                            : null
                                                    }

                                                    <div className="form-group row" style={{ marginTop: '10px' }}>
                                                        <div className="col-sm-10">
                                                            <button
                                                                className="btn btn-primary"
                                                                type="submit"
                                                            > Update
                                                            </button>
                                                        </div>
                                                    </div>

                                                    {message && (
                                                        <div className="form-group">
                                                            <div
                                                                className={
                                                                    //this.state.successful
                                                                    //? "alert alert-success"
                                                                    //:
                                                                    "alert alert-danger"
                                                                }
                                                                role="alert"
                                                            >
                                                                {message}
                                                            </div>
                                                        </div>
                                                    )}
                                                </form>
                                            }
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Fragment>
                        :
                        <Fragment>
                            {
                                !isProfileLoaded
                                    ? <Spinner />
                                    :
                                    <Fragment>
                                        <PrintPdfButton
                                            label="Print Card"
                                            id="profile-card"
                                            pdfName={`profile-card-${userName}`}
                                        />
                                        <div className="card mb-3" style={{ maxWidth: '540px' }}>
                                            <div className="row no-gutters" id="profile-card">
                                                <div className="col-md-4">
                                                    {
                                                        !userAvatar
                                                            ? (<img src='http://localhost:8080/public/images/avatars/avatar.png' className="card-img" alt={userName} />)
                                                            : (<img src={`http://localhost:8080/${userAvatar}`} className="card-img" alt={userName} />)
                                                    }
                                                </div>
                                                <div className="col-md-8">
                                                    <div className="card-body">
                                                        <h5 className="card-title"><u>{`Welcome ${userName}`}</u></h5>
                                                        <p className="card-text">{`Your Email ID: ${userEmail}`}</p>
                                                        <p className="card-text"><small className="text-muted">Last updated 3 mins ago</small></p>
                                                        <p  data-html2canvas-ignore="true">
                                                            <ul className="list-inline m-0">
                                                                <li className="list-inline-item">
                                                                    <a
                                                                        className="badge badge-info"
                                                                        onClick={() => setEditMode(true)}
                                                                    >Update Profile</a>
                                                                </li>
                                                            </ul>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </Fragment>
                            }
                        </Fragment>
                }
            </div>
        </Fragment>
    )
}

export default Profile
