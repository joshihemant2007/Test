import React, { useEffect } from 'react'

const Paginator = (props) => {
    let textInput = null
    useEffect(() => {
        textInput.focus();
    })

    let mapper = [];

    let i = 1
    let j = props.totalPages
    for (i; i <= j; i++) {
        let active = ''
        if (i === props.currentPage) {
            active = 'active'
        }

        mapper.push({ 'num': i, 'liActiveClass': active })
    }

    const li = mapper.map(({ num, liActiveClass }) => {
        return <li className={`page-item ${liActiveClass}`} key={num} onClick={() => props.onPagination(num)}>
            <a className="page-link" href="javascript: void(0)">{num} {liActiveClass === 'active' ? <span className="sr-only">(current)</span> : null}</a>
        </li>
    })


    return (
        <nav aria-label="...">
            <ul className="pagination justify-content-center">
                <li className={`page-item  ${props.previousDisabled}`}>
                    <a className="page-link" onClick={() => props.onPagination('previous')} href="javascript: void(0)" tabindex="-1" aria-disabled="true">Previous</a>
                </li>

                {
                    li.length > 0 ? li : ''
                }

                <li className={`page-item  ${props.nextDisabled}`}>
                    <a className="page-link" onClick={() => props.onPagination('next')} href="javascript: void(0)">Next</a>
                </li>
            </ul>

            {
                props.enableSearch &&
                (<input
                    class="form-control mr-sm-2"
                    placeholder="Search By Title"
                    aria-label="Search"
                    type="search"
                    name="search"
                    onChange={(e) => props.onSearch(e.target.value)}
                    value={props.searchStr}
                    ref={(inputTxt) => { textInput = inputTxt }}
                ></input>)
            }

        </nav>
    )
}

export default Paginator
