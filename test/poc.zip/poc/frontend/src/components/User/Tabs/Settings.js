import React, { Component } from 'react'

class Settings extends Component {
    render() {
        return (
            <div className="tab-pane text-center show active" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                Settings
            </div>
        )
    }
}

export default Settings
