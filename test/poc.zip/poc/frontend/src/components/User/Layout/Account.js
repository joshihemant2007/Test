import React, { Component, Fragment } from 'react'
import { Switch, Route, NavLink, withRouter } from 'react-router-dom'

import Dashboard from '../Tabs/Dashboard';
import Profile from '../Tabs/Profile';
import Message from '../Tabs/Message';
import Settings from '../Tabs/Settings';
import AddBlog from '../../Blog/AddBlog'
import Stories from '../Tabs/Stories'

class Account extends Component {
    render() {
        let active
        if (this.props.location.pathname == '/account') {
            active = 'active'
        }

        return (
            <Fragment>
                <div className="container">
                    <p></p>
                    <div className="row">
                        <div className="col-2 border-right">
                            <div className="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <NavLink to="/account/dashboard/" className={"nav-link " + active} id="v-pills-dashboard-tab" data-toggle="pill" href="#v-pills-dashboard" role="tab" aria-controls="v-pills-dashboard" aria-selected="true">
                                    Dashboard
                                </NavLink>
                                <NavLink to="/account/profile" className="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">
                                    Profile
                                </NavLink>
                                <NavLink to="/account/add-blog" className="nav-link">
                                    Add Blog
                                </NavLink>
                                <NavLink to="/account/message" className="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
                                    Messages
                                </NavLink>
                                <NavLink to="/account/settings" className="nav-link">
                                    Settings
                                </NavLink>
                                <NavLink to="/account/stories" className="nav-link">
                                    Stories
                                </NavLink>
                            </div>
                        </div>
                        <div className="col-10">
                            <div className="tab-content" id="v-pills-tabContent">
                                <Switch>
                                    <Route path="/account/add-blog" exact component={() => <AddBlog {...this.props} />} />
                                    <Route path="/account/blog/edit/:id" exact component={() => <AddBlog {...this.props} />} />
                                    <Route path="/account/profile" component={() => <Profile />} />
                                    <Route path="/account/message" component={() => <Message />} />
                                    <Route path="/account/settings" component={() => <Settings />} />
                                    <Route path="/account/stories" component={() => <Stories />} />
                                    <Route path="/account/dashboard" component={() => <Dashboard  />} />
                                    <Route path="/account" component={() => <Dashboard  />} />
                                </Switch>
                            </div>
                        </div>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default Account