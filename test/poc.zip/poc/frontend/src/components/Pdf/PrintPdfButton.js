import React, { useState } from 'react'

import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'

const PdfButton = (props) => {
    const [loading, setLoading] = useState(false)
    // const pxToMm = (px) => {
    //     return Math.floor(px / document.getElementById('myMm').offsetHeight)
    // }

    // const mmToPx = (mm) => {
    //     return document.getElementById('myMm').offsetHeight * mm
    // }

    // const range = (start, end) => {
    //     return Array(end - start).join(0).split(0).map(function (val, id) { return id + start })
    // }

    const printToPDF = async () => {
        setLoading(true)
        //const input = document.getElementById(props.id);
        // const inputHeightMm = pxToMm(input.offsetHeight);
        // const a4WidthMm = 210;
        // const a4HeightMm = 297;
        // const a4HeightPx = mmToPx(a4HeightMm);
        // const numPages = inputHeightMm <= a4HeightMm ? 1 : Math.floor(inputHeightMm / a4HeightMm) + 1;
        // console.log({
        //     input, inputHeightMm, a4HeightMm, a4HeightPx, numPages, range: range(0, numPages),
        //     comp: inputHeightMm <= a4HeightMm, inputHeightPx: input.offsetHeight
        // });

        // const input = document.getElementById(props.id)
        // Adding attribute data-html2canvas-ignore to html element will ignore that from printing
        // OR you can set predicate functon for ignoreElements attribute
        // refer http://html2canvas.hertzen.com/configuration/
        const input = document.getElementById(props.id);

        const canvas = await html2canvas(input, {
            attribute: true,
            type: false,
            default: false,
            useCORS: true,
            imageTimeout: 0,
            logging: true,
            scale: 2, // clear font
            // dpi: 200,
            // ignoreElements: function (el) {
            // return el.className.toLowerCase() === 'pdf-ignore'
            // },
            // ignoreElements: function (el) { },
            // backgroundColor: null,
        })
        //.then((canvas) => {

        const imgData = await canvas.toDataURL('image/png')

        var imgWidth = 200;
        var pageHeight = 295;
        var imgHeight = canvas.height * imgWidth / canvas.width;
        var heightLeft = imgHeight;

        var pdf = new jsPDF('p', 'mm');
        var position = 0;

        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;

        while (heightLeft >= 0) {
            position = heightLeft - imgHeight;
            pdf.addPage();
            pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
            heightLeft -= pageHeight;
        }
        await pdf.save(props.pdfName);
        setLoading(false)

        // // Document of a4WidthMm wide and inputHeightMm high
        // let pdf
        // if (inputHeightMm > a4HeightMm) {
        //     // elongated a4 (system print dialog will handle page breaks)
        //     pdf = new jsPDF('p', 'mm', [inputHeightMm + 16, a4WidthMm])
        // } else {
        //     // standard a4
        //     pdf = new jsPDF()
        // }
        // const imgProps = pdf.getImageProperties(imgData);
        // const pdfWidth = pdf.internal.pageSize.getWidth();
        // const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        // pdf.deletePage(1);
        // pdf.addPage(250, 300);
        // pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight)
        // pdf.save(props.pdfName)
        // }).then(res => {
        //     alert('done')
        // })
    }

    return (
        <div data-html2canvas-ignore>
            <div id="myMm" style={{ height: "1mm" }} />
            <button
                className="btn btn-warning float-right"
                style={{marginRight: '10px'}}
                type="button"
                onClick={printToPDF}
                disabled={loading}
            >
                {
                    loading ? <span className="spinner-border spinner-border-sm"></span> : null
                }
                {props.label}
            </button>
        </div>
    )
}

export default PdfButton
