import React from 'react'

const Contact = () => {
    return (
        <div className="container">
            <p></p>
            <p className="text-justify">Choosing what to blog about or picking a niche for your blog can be easy or hard, depending on how you decide to go about it. The easy way would be to pick something that you like to write about. You can share a personal information by exploring hobbies, documenting your life, etc.</p>
            <p className="text-justify">But, it can be a bit trickier if you wish for your blog to make an impact and to draw attention to itself. If you want a quality blog that brings something new to the table and interesting to readers, then you will need to consider a lot of different things. You need to come up with a good strategy to make your content more visible.
            </p>
            <p className="text-justify">We assume that you already created your blog, and we are going to go in-depth on how you should choose what to blog about, and how to create posts that are going to have generic engagement. We are also going to provide you with some blog post examples that went viral to exemplify the points covered in this article..</p>
        </div>
    )
}

export default Contact