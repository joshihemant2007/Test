const AppTheme = {
    light: 'navbar-light bg-light',
    dark: 'navbar-dark bg-dark'
}

export default AppTheme