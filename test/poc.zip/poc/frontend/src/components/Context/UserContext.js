import React from 'react'

const UserContext = React.createContext({user: {}}); // Create a context object

export default UserContext