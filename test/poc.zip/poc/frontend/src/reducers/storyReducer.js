const storyReducer = (state = [], action) => {

    switch (action.type) {

        case 'ADD_STORY':
            let stateCopy1 = [...state, action.payload]
            localStorage.setItem('stories', JSON.stringify(stateCopy1))
            return stateCopy1

        case 'DELETE_STORY':
            let stateCopy2 = state.filter(x => x.id !== action.payload)
            localStorage.setItem('stories', JSON.stringify(stateCopy2))
            return stateCopy2

        case 'UPDATE_STORY':
            // console.log('==============', state)
            let stateCopy3 = state.map((story) => {
                const { id, title, desc } = action.payload
                if (story.id === id) {
                    story.title = title
                    story.desc = desc
                }
                return story
            })
            localStorage.setItem('stories', JSON.stringify(stateCopy3))
            return stateCopy3

        default:
            return state
    }
}

export default storyReducer