﻿using System;

namespace WiredBrainCoffee.ShopInfoTool
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Wired Brain Coffee - Shop Info Tool!");
    }
  }
}
