Hi Visual Studio 2019 Developer,

we created in this module a new solution, so there's nothing in this folder.
Look in the after folder to see what was created in this module.

Thanks,
Thomas Claudius Huber
www.thomasclaudiushuber.com