Hi Visual Studio 2019 Developer,

we haven't made any code changes in this module, so there's nothing in this after folder.
Look in the before folder, there's the solution that we used in this module.

Thanks,
Thomas Claudius Huber
www.thomasclaudiushuber.com