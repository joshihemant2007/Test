﻿namespace WiredBrainCoffee.ShopInfoTool
{
  internal interface ICommandHandler
  {
    void HandleCommand();
  }
}