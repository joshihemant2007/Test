﻿namespace WiredBrainCoffee.DataAccess.Model
{
  public class CoffeeShop
  {
    public string Location { get; set; }

    public int BeansInStockInKg { get; set; }
  }
}
