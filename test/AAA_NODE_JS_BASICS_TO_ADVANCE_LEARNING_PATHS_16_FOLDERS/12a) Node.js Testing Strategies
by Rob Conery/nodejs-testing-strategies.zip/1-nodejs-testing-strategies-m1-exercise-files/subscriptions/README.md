# Hi There

This is the demo project for Node Testing Strategies at Pluralsight. This project has a git history you might want to explore in case you want to know what's going on in each module.

To get things started, but sure to `npm install` your modules.

You can see that by using `git log`.

Once you find a commit that you think has the code you're looking for (I tried to comment things based on each module), you can check it out. For instance, this commit:

```
commit 8a3812ccf1cc72893b3f2a2e303fe0006143b065
Author: Rob Conery <robconery@gmail.com>
Date:   Wed Feb 25 13:23:07 2015 +0100

    review process initial tests firing
```

Can be checked out with `git checkout 8a3812ccf1cc72893b3f2a2e303fe0006143b065`. This will detach the HEAD and update your working directory.

To get back to this checkout, use `git checkout master`.

Have fun!

-- Rob