# Node real-time log dashboard

To start the application, in a terminal type: <code>npm start</code>

Then, in a browser, go to: <code>http://localhost:3000/</code>

Follow the <b>Select File</b> link and open the <b>log-generator>sample.log</b> file

### Note: This project was generated with <b>express-generator</b>, e.g.
```
$ express --view=ejs log-dashboard
```