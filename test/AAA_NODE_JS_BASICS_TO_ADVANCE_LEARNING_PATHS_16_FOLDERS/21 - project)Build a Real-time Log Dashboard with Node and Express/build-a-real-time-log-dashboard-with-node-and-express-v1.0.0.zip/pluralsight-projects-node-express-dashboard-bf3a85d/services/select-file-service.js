function getDirectoryContents(files, currentDir, query) {
}

function isDirectory(currentDir, file) {
}

function readDir(currentDir, res, query) {
}

exports.get = (req, res) => {
};
