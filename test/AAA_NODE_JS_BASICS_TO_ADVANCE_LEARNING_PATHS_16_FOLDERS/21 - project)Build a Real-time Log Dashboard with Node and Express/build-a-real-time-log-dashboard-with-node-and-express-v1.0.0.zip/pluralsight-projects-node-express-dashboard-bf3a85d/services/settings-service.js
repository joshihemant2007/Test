function getSettings() {
  return {}
}

function writeSettings(newSettings) {
}

function getDefaultDir() {
}

function isValidDir(dirPath) {
}

module.exports = {
  getSettings,
  writeSettings,
  getDefaultDir,
  isValidDir
};