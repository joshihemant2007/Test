These directories contain the repository that I used in the screencast, copied after the end of each training module. You can use it to make your own experiments. Also, if you're like me, you'll find it much easier to remember the commands if you type them yourself.

The example project for this training is also on GitHub (https://github.com/nusco/cookbook). Use this command to clone it to your computer:

    git clone https://github.com/nusco/cookbook

I love feedback, so I hope to meet you on this training's discussion forum. Have fun, and enjoy Mastering Git!

   Paolo Perrotta
