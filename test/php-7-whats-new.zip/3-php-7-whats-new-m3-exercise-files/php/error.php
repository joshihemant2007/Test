<?php

    try {
        $uc = new UnknownClass();
    } catch (Error $er) {

    }
