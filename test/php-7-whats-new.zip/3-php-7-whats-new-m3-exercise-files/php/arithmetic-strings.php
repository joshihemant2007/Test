<?php

var_dump((int)'71E-1');

var_dump('PHP ' + '7.1.0 is available!');