<?php

function createUser($name, $password, $role) {
    // ...
    echo 'User created.';
}

createUser('Christian', 'V3ry5ecret');