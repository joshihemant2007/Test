<?php

    list($shoppingCart[], $shoppingCart[], $shoppingCart[]) = ['PHP 4', 'PHP 5', 'PHP 7'];

    print_r($shoppingCart);