<?php

    echo 012345678;