<?php

    var_dump(1/0);
    echo '<br>';
    var_dump(0/0);
    echo '<br>';
    var_dump(0%0);