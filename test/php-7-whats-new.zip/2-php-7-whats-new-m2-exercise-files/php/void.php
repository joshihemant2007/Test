<?php

function gc(): void {
    return;
}

gc();