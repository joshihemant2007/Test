<?php
    function addItemsToBasket($item1, $item2, $item3) {
        //var_dump($items);
    }

    addItemsToBasket(...['A', 'B', 'C']);