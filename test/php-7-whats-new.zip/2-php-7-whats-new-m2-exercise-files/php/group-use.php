<?php
    require_once 'namespaces.php';

    use myNS\{A as A, B, C};

