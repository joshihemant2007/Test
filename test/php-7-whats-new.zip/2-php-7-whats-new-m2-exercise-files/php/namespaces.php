<?php
    namespace myNS;

    class A {}
    class B {}
    class C {}
