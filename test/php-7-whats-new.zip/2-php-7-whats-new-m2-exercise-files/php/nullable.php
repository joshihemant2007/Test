<?php

function createUser(string $name, string $password, ?string $role): bool {

    return true;
}

createUser('Christian', 'T0pSecr3t');