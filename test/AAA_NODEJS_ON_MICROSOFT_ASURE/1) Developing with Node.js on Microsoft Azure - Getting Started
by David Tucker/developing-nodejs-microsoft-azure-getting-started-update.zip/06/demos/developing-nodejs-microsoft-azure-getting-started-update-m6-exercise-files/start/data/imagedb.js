const { 
  BlobServiceClient, 
  BlobSASPermissions, 
  generateBlobSASQueryParameters 
} = require('@azure/storage-blob');

const moment = require('moment');
const { v1: uuidv1 } = require('uuid');

const CONNECTION_STRING = '';
const containerName = '';

module.exports.uploadImage = async (stream) => {
  
};

module.exports.getImageUri = async (id) => {
  
};
