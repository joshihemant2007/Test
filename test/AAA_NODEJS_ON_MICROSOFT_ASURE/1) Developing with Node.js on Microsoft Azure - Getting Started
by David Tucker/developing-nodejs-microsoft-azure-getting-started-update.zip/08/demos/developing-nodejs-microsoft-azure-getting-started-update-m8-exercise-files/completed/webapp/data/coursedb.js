const CosmosClient = require('@azure/cosmos').CosmosClient;
const coursesData = require('./courses.json');

const client = new CosmosClient({
  endpoint: '<insert endpoint>',
  key: '<insert key>'
});

const databaseId = '<insert database id>';
const containerId = '<insert container id>';

let container;

const getContainer = async () => {
  if(!container) {
    container = await client.database(databaseId).container(containerId);
  }
  return container;
}

module.exports.queryCourses = async () => {
  const c = await getContainer();
  const { resources } = await c.items.readAll().fetchAll();
  return resources;
};

module.exports.createCourses = async () => {
  const c = await getContainer();
  await Promise.all(coursesData.map(course => c.items.create(course)));
  return { itemCount: coursesData.length };
}; 

