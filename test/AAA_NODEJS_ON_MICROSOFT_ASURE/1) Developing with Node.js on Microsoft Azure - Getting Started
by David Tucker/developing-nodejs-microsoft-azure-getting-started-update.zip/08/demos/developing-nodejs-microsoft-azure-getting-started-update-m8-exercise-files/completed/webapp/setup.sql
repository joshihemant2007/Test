CREATE USER webappdbuser WITH PASSWORD='QeCixM2qjYvQPafwkzFF'

EXECUTE sp_addrolemember db_datareader, "webappdbuser"
EXECUTE sp_addrolemember db_datawriter, "webappdbuser"

CREATE TABLE users
(
  id INT IDENTITY PRIMARY KEY,
  name nvarchar(255),
  email nvarchar(255)
);

select * from users
