const { Connection, Request } = require('tedious');

const config = {
  authentication: {
    options: {
      userName: '<insert username>',
      password: '<insert password>'
    },
    type: 'default'
  },
  server: '<insert server>',
  options: {
    database: '<insert database>',
    encrypt: true,
    trustServerCertificate: false,
    rowCollectionOnRequestCompletion: true
  }
};

const getConnection = async () => {
  return new Promise((resolve, reject) => {
    const connection = new Connection(config);
    connection.on('connect', (err) => {
      if(err) {
        reject(err);
      } else {
        resolve(connection);
      }
    });
  });
}

const executeQuery = async (sql) => {
  return new Promise(async (resolve, reject) => {
    try {
      const connection = await getConnection();
      const request = new Request(sql, (err, rowCount, rows) => {
        if(err) {
          reject(err);
        } else {
          resolve({ rowCount: rowCount, rows: rows });
        }
      });
      connection.execSql(request);
    } catch(err) {
      reject(err);
    }
  });
};

module.exports.createUsers = async () => {
  const sql = `
  INSERT INTO USERS (name, email) VALUES ('David', 'david@globomantics.com')
  INSERT INTO USERS (name, email) VALUES ('Jane', 'jane@globomantics.com')
  INSERT INTO USERS (name, email) VALUES ('Edward', 'edward@globomantics.com')
  `;
  return await executeQuery(sql);
};

module.exports.queryUsers = async () => {
  const sql = `SELECT * FROM users`;
  return await executeQuery(sql);
};
