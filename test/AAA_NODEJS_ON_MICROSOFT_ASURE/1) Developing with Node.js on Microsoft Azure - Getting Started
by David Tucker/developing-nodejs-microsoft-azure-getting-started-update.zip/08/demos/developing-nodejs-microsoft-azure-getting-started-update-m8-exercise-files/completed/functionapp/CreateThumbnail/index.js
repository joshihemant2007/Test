const Jimp = require('jimp');

module.exports = async function (context, myBlob) {
    try {
      const image = await Jimp.read(myBlob);
      await image.resize(300, Jimp.AUTO);
      const outputBuffer = await image.getBufferAsync(Jimp.MIME_JPEG);
      context.bindings.outputBlob = outputBuffer;
    } catch(err) {
      context.log("Error: " + err.message);
    }
};