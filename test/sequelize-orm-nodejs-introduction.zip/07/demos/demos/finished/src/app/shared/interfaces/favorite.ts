export interface Favorite {
  id?: number;
  title: string;
}
