exports.test = (req, res) => {
  res.send('API user route works!');
}
