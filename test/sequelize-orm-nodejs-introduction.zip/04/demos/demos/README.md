1. Type `npm i` to download packages
2. Type `npm start` to run project
