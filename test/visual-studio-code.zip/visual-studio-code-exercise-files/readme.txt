All code samples can be found in the code.zip file

Instructions for using them are in the course. Quick start commands for the samples are in the readme.md file in the root of the code folder, ince extracted from the code.zip file.
