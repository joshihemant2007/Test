import React from 'react';

const PropViewer = ({match, location}) => {

    return (
        <h1>
            {location.key}
        </h1>
    );

};

export default PropViewer;
