class API {

    getAuthors = () => {
        return [
            {id: 1, name: 'David Starr', occupation: 'Technical Learning Director'},
            {id: 2, name: 'Scott Allen', occupation: 'Web Developer'},
            {id: 3, name: 'Matt Milner', occupation: 'Programmer Extraordinaire'},
            {id: 4, name: 'Ben Day', occupation: 'Pluralsight Author & Consultant'},
            {id: 5, name: 'Cory House', occupation: 'React.js Guru'}
        ]
    };
}

export default API;