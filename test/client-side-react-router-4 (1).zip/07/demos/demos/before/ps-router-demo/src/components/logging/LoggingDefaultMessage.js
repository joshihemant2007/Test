import React from 'react';

const LoggingDefaultMessage = () => {

    return (
        <div>
            <h3>Front Matter</h3>
            <p>
                This page is not being logged. The links above should log an event whenever they are clicked.
            </p>
        </div>
    );

};

export default LoggingDefaultMessage;