import React from 'react';
import {Link} from "react-router-dom";

const ProtectedComponent2 = () => {

    return (

        <div>
            <h2>Protected Component 2</h2>

            <p>
                Ultricies integer quis auctor elit sed. Neque convallis a cras semper auctor neque vitae tempus quam. At
                elementum eu facilisis sed odio morbi quis. Auctor elit sed vulputate mi sit amet mauris commodo. At
                imperdiet dui accumsan sit. Quis lectus nulla at volutpat. Ac tincidunt vitae semper quis lectus nulla
                at. Vel pharetra vel turpis nunc eget lorem dolor sed viverra. Lacus suspendisse faucibus interdum
                posuere lorem ipsum. Elit ut aliquam purus sit amet. Sed ullamcorper morbi tincidunt ornare massa.
                Semper risus in hendrerit gravida rutrum quisque non tellus.
            </p>

        </div>


    );
};

export default ProtectedComponent2;