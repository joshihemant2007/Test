import React from 'react';

const LoggingDefaultMessage = () => {

    return (
        <div>
            <h3>Front Matter</h3>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris tincidunt, dui ac condimentum pharetra, massa ligula pretium enim, nec dictum ligula orci quis mauris. Maecenas in malesuada ante. Etiam auctor tellus nec metus suscipit, at malesuada elit dictum. Vivamus tellus augue, pulvinar sed interdum id, suscipit eu arcu. Duis volutpat condimentum auctor. Nulla facilisi. Nullam tincidunt lobortis pharetra.
            </p>
        </div>
    );

};

export default LoggingDefaultMessage;