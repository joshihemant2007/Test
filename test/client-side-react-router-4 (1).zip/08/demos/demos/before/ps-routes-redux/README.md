# ps-routes-redux

A project for use when demoing redux.

Includes React Router 4.
