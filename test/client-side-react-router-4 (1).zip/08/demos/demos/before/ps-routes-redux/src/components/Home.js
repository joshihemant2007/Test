import React from 'react';

const Home = () => {

    return (
        <div>
            <img src='/assets/codelife.png'/>
            <h3>People and Places</h3>
        </div>

    );

};

export default Home;