export const ADD_PERSON = 'ADD_PERSON';
export const DELETE_PERSON = 'DELETE_PERSON';
export const EDIT_PERSON = 'EDIT_PERSON';
export const UPDATE_PERSON = 'UPDATE_PERSON';

export const ADD_PLACE = 'ADD_PLACE';
export const DELETE_PLACE = 'DELETE_PLACE';
export const EDIT_PLACE = 'EDIT_PLACE';
export const UPDATE_PLACE = 'UPDATE_PLACE';


