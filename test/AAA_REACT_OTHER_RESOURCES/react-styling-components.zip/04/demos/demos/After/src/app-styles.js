export default {
  '*': {
    boxSizing: 'border-box'
  },
  html: {
    fontFamily: '"Helvetica Neue", Helvetica, Arial, sans-serif',
    fontSize: 14,
    lineHeight: '1.4em',
    backgroundColor: '#1D272F'
  }
}
