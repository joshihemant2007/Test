import config from './config-styles.js'

export default {
  root: {
    position: 'relative',
    overflow: 'hidden',
    height: config.imageHeight
  }
}
