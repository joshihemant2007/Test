export default {
  imageWidth: 640,
  imageHeight: 420
}
