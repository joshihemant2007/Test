# react-drift

Example app for React Component styling

## Styling methods

- Inline styles
- Radium
- External CSS
- CSS modules

## Install

```
git clone git@github.com:jaketrent/react-drift.git
npm install
```

## Run

```
npm start
open http://localhost:3000
```

Includes only dev environment build target.
