import React from 'react'
import ReactDOM from 'react-dom'

import DriftApp from './app.js'

ReactDOM.render(<DriftApp />, document.getElementById('app'))
