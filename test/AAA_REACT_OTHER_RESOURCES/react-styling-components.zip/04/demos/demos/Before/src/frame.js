import React from 'react'

export default function Frame({ children }) {
  return <div>{children}</div>
}
