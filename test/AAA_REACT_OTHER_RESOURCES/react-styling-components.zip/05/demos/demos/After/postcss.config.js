module.exports = {
  plugins: {
    'postcss-import': {},
    'postcss-preset-env': {}
  }
}
