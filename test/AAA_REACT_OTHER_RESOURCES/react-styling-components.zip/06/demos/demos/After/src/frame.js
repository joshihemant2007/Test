import React from 'react'

export default function Frame({ children }) {
  return <div className="dft__frame">{children}</div>
}
