import config from './config-styles'

export default {
  root: {
    maxWidth: '100%',
    width: config.imageWidth,
    margin: '50px auto'
  }
}
