import keyMirror from 'keymirror';

export var ActionTypes = keyMirror({
  CHANGE_ORIGIN_AMOUNT: null
})

console.log('ActionTypes', ActionTypes);
