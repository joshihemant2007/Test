`index.js` contains our tiny-redux implementation.

## Instructions
With node, you can run `node index.js`

In the browser, you could just paste the code into the console.

## Caveats
- createStore(), combineReducers(), applyMiddleware() appear to work according to the API. This is mainly intended for learning purposes. Not meant for production use.
