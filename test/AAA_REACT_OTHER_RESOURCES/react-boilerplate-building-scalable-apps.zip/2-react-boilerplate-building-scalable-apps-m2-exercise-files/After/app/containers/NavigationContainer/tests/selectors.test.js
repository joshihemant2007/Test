// import { selectNavigationContainerDomain } from '../selectors';
// import { fromJS } from 'immutable';
import expect from 'expect';

// const selector = selectNavigationContainerDomain();

describe('selectNavigationContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect('Test case').toEqual(false);
  });
});
