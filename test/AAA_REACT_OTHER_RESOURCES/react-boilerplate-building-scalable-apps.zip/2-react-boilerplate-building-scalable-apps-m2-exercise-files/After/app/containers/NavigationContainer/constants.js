/*
 *
 * NavigationContainer constants
 *
 */

export const DEFAULT_ACTION = 'app/NavigationContainer/DEFAULT_ACTION';
