// import { selectLinkListContainerDomain } from '../selectors';
// import { fromJS } from 'immutable';
import expect from 'expect';

// const selector = selectLinkListContainerDomain();

describe('selectLinkListContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect('Test case').toEqual(false);
  });
});
