/*
 *
 * LinkListContainer constants
 *
 */

export const DEFAULT_ACTION = 'app/LinkListContainer/DEFAULT_ACTION';
