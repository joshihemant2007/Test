/*
 *
 * NavigationContainer constants
 *
 */

export const REQUEST_TOPICS = 'app/NavigationContainer/REQUEST_TOPICS';
export const REQUEST_TOPICS_SUCCEEDED = 'app/NavigationContainer/REQUEST_TOPICS_SUCCEEDED';
export const REQUEST_TOPICS_FAILED = 'app/NavigationContainer/REQUEST_TOPICS_FAILED';
