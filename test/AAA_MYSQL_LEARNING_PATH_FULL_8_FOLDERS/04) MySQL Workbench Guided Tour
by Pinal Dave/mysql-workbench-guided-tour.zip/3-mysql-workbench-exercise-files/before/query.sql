USE sakila;

SELECT 
    *
FROM
    film
ORDER BY film_id;

SELECT *
FROM film 
INNER JOIN film_actor ON film.film_id = film_actor.film_id;


SELECT *
FROM film
WHERE film_id = 1;

UPDATE film
SET title = 'SUPER BIG DINOSAUR'
WHERE film_id = 1;

SELECT *
FROM film
WHERE film_id = 1;