module.exports = {
    "extends": "standard",
    "env": {
        "node": true,
        "mocha": true
    }
};