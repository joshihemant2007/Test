<?php
/**
 * Template Name: Front Page
 * The template for displaying the home page.
 *
 * @package _s
 * @since _s 1.0
 */
$options = get_option('zmo_theme_options');
$detect = new Mobile_Detect();
if (!$detect->isMobile() || ( $detect->isTablet() && $options['home_js'] != 'carousel' ) ) {
    get_header('home');
    $is_mobile = false;
} else {
    get_header('mobile');
    $is_mobile = true;
}

$home_features = get_home_features();
if ( $options['home_js'] == 'carousel' ) { ?>
        <?php
        $caption = 0; ?>
        <div class="<?php if ( $is_mobile ) { echo 'mobile-caption'; } else { echo 'carousel-caption'; } ?>">
            <?php foreach ( $home_features as $feature ){
                $post_id = $feature['id'];
                $linked_page = get_post_meta( $post_id, 'related_page_1', true );
                if ( $post_id != null ) { ?>
                <div id="slidecaption<?php echo $caption; $caption++; ?>">
                    <h3 class="linked-title"><a href="<?php echo get_permalink($linked_page); ?>"><?php echo get_the_title($linked_page); ?></a>
                    <h1><a href="<?php echo get_permalink($linked_page); ?>"><?php echo get_the_title($post_id); ?></a></h1>
                    <?php echo get_my_excerpt( $post_id ); ?>
                    <a class="readmore" href="<?php echo get_permalink($linked_page); ?>">[read more]</a>
                </div>
                <?php }
            }
            if ( !$is_mobile ) { ?><a id="nextslide">[next page]</a><?php } ?>
        </div>
<?php }
if ( $options['home_js'] == 'bigvideo' ) {
	foreach ( $home_features as $feature ) {
		$post_id = $feature['id'];
        $linked_page = get_post_meta( $post_id, 'related_page_1', true );
		if ( $post_id != null ) { ?>
    		<div class="<?php if ( $is_mobile ) { echo 'mobile-caption'; } else { echo 'carousel-caption bigvideo span6'; } ?>">
                <h3 class="linked-title"><a href="<?php echo get_permalink($linked_page); ?>"><?php echo get_the_title($linked_page); ?></a>
    			<h1><a href="<?php echo get_permalink($linked_page); ?>"><?php echo get_the_title($post_id); ?></a></h1>
    				<?php echo get_my_excerpt( $post_id ); ?>
                    <a class="readmore" href="<?php echo get_permalink($linked_page); ?>">[read more]</a>
   			</div>
		<?php }
		}
    if ( !$is_mobile ) { ?>
    <script type="text/javascript">
    //<![CDATA[
    /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    Disable context menu on images by GreenLava (BloggerSentral.com)
    Version 1.0
    You are free to copy and share this code but please do not remove this credit notice.
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
        function nocontext(e) {
            var clickedTag = (e==null) ? event.srcElement.tagName : e.target.tagName;
            if (clickedTag == "VIDEO") {
                alert(alertMsg);
                return false;
            }
        }
        var alertMsg = "This video is protected by copyright law. Right click is disabled.";
        document.oncontextmenu = nocontext;
    //]]>
    </script>
    <div class="wrapper">
    	<?php
    	$screen_id = 1;
    	foreach ( $home_features as $feature ) {
    		$post_id = $feature['id'];
    		$vid_url = $feature['image'];
    		if ( $post_id != null ) { ?>
    			<div class="screen" id="screen-<?php echo $screen_id; ?>" data-video="<?php echo $vid_url; ?>">
    				<img src="<?php echo trailingslashit(get_template_directory_uri()) . 'img/IMG' . $screen_id; ?>.JPG" style="left: 0!important;" class="big-image" />
    			</div>
    		<?php $screen_id++;
    		}
    	}
    	?>
    </div>
    <script>
        jQuery(document).ready(function($) {

            // Use Modernizr to detect for touch devices,
            // which don't support autoplay and may have less bandwidth,
            // so just give them the poster images instead
            var screenIndex = 1,
                numScreens = $('.screen').length,
                isTransitioning = false,
                transitionDur = 1000,
                BV,
                videoPlayer,
                isTouch = Modernizr.touch,
                $bigImage = $('.big-image'),
                $window = $(window);

            if (!isTouch) {
                // initialize BigVideo
                BV = new $.BigVideo({forceAutoplay:isTouch});
                BV.init();
                showVideo();

                BV.getPlayer().addEvent('loadeddata', function() {
                    onVideoLoaded();
                });

                // adjust image positioning so it lines up with video
                $bigImage
                    .css('position','relative')
                    .imagesLoaded(adjustImagePositioning);
                // and on window resize
                $window.on('resize', adjustImagePositioning);
            }

            // Next button click goes to next div
            $('#next-btn').on('click', function(e) {
                e.preventDefault();
                if (!isTransitioning) {
                    next();
                }
            });

            function showVideo() {
                BV.show($('#screen-'+screenIndex).attr('data-video'),{ambient:true});
            }

            function next() {
                isTransitioning = true;

                // update video index, reset image opacity if starting over
                if (screenIndex === numScreens) {
                    $bigImage.css('opacity',1);
                    screenIndex = 1;
                } else {
                    screenIndex++;
                }

                if (!isTouch) {
                    $('#big-video-wrap').transit({'left':'-100%'},transitionDur)
                }

                (Modernizr.csstransitions)?
                    $('.wrapper').transit(
                        {'left':'-'+(100*(screenIndex-1))+'%'},
                        transitionDur,
                        onTransitionComplete):
                    onTransitionComplete();
            }

            function onVideoLoaded() {
                $('#screen-'+screenIndex).find('.big-image').transit({'opacity':0},500)
            }

            function onTransitionComplete() {
                isTransitioning = false;
                if (!isTouch) {
                    $('#big-video-wrap').css('left',0);
                    showVideo();
                }
            }

            function adjustImagePositioning() {
                $bigImage.each(function(){
                    var $img = $(this),
                        img = new Image();

                    img.src = $img.attr('src');

                    var windowWidth = $window.width(),
                        windowHeight = $window.height(),
                        r_w = windowHeight / windowWidth,
                        i_w = img.width,
                        i_h = img.height,
                        r_i = i_h / i_w,
                        new_w, new_h, new_left, new_top;

                    if( r_w > r_i ) {
                        new_h   = windowHeight;
                        new_w   = windowHeight / r_i;
                    }
                    else {
                        new_h   = windowWidth * r_i;
                        new_w   = windowWidth;
                    }

                    $img.css({
                        width   : new_w,
                        height  : new_h,
                        left    : ( windowWidth - new_w ) / 2,
                        top     : ( windowHeight - new_h ) / 2
                    })

                });

            }
        });
    </script>
    <?php } ?>
<?php }
if ( $is_mobile ) {
    get_footer();
} else {
    get_footer('home');
} ?>