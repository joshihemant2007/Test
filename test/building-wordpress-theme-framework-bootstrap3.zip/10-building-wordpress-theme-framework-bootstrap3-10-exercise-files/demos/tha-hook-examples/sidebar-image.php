<?php
function display_sidebar_image( $image ) {
	if ( !empty( $image ) ) {
		$sidebar_image = esc_url_raw( $image );
	} else {
		$sidebar_image = 'http://hhhhold.com/250x250/';
	}

	echo '<img src="' . $sidebar_image . '" />';
}
add_action( 'tha_sidebar_bottom', 'display_sidebar_image' );
?>