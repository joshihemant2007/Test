<?php
function pluralsight_related_posts() {
	if ( is_page( 'some-page' ) ) {
		related_posts();
	}
}
add_action( 'tha_content_bottom', 'pluralsight_related_posts' );
?>