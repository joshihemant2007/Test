<!doctype html>
<?php tha_html_before(); ?>
<html <?php language_attributes(); ?>>
<head>
<?php tha_head_top(); ?>
<meta charset="<?php bloginfo('charset'); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<?php $options = get_option( 'ap_core_theme_options' ); ?>
<?php
	$ap_core_fixed_nav = null;
	if ( isset( $options['nav-menu'] ) && ( true == $options['nav-menu'] ) ) {
		$ap_core_fixed_nav = 'bs-fixed-nav';
	}

	$ap_core_navbar_inverse = null;
	if ( isset( $options['navbar-inverse'] ) && ( true == $options['navbar-inverse'] ) ) {
		$ap_core_navbar_inverse = 'navbar-inverse';
	} else {
		$ap_core_navbar_inverse = 'navbar-default';
	}
?>
<title><?php wp_title(); ?></title>
<?php tha_head_bottom(); ?>
<?php wp_head(); ?>
</head>
<body <?php body_class( $ap_core_fixed_nav ); ?>>
<?php tha_body_top(); ?>
	<div class="container" id="wrap">
		<?php tha_header_before(); ?>
		<header>
			<?php tha_header_top(); ?>
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-1-collapse">
					<i class="icon-reorder" title="Menu"></i>
				</button>
			</div>
			<?php
				$ap_core_navbar_default = array( 'container' => 'nav', 'container_class' => 'topnav ' . $ap_core_navbar_inverse . ' collapse navbar-collapse navbar-1-collapse', 'theme_location' => 'top', 'fallback_cb' => false, 'menu_class' => 'nav navbar-nav', 'walker' => new ap_core_wp_bootstrap_navwalker() );
				$ap_core_navbar_fixed = array( 'container' => 'nav', 'container_class' => 'topnav ' . $ap_core_navbar_inverse . ' navbar navbar-default navbar-fixed-top', 'theme_location' => 'top', 'fallback_cb' => false, 'menu_class' => 'nav navbar-nav', 'walker' => new ap_core_wp_bootstrap_navwalker() );
			if ( $ap_core_fixed_nav ) {
				// if the nav menu is fixed
				wp_nav_menu( $ap_core_navbar_fixed );
			} else {
				wp_nav_menu( $ap_core_navbar_default );
			} ?>

			<hgroup class="siteinfo">
				<?php if ($options['alth1'] == true) { ?>
					<h2 ><span class="alt"><a href="<?php echo esc_url( home_url() ) ?>" title="<?php bloginfo('title'); ?>"><?php bloginfo('title'); ?></a></span> <small class="hidden-sm hidden-xs"><?php bloginfo('description'); ?></small></h2>
				<?php } else { ?>
					<h2><a href="<?php echo esc_url( home_url() ) ?>" title="<?php bloginfo('title'); ?>"><?php bloginfo('title'); ?></a> <small class="alt hidden-sm hidden-xs"><?php bloginfo('description'); ?></small></h2>
				<?php } ?>
			</hgroup>

			<?php
			$sticky = get_option( 'sticky_posts' );
			$args = array(
				'post__in' => $sticky,
				'ignore_sticky_posts' => 1,
			);
			$count = 0;
			$carousel = new WP_Query( $args );
			if ( $carousel->have_posts() ) : ?>
				<div id="sticky-carousel" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner">
						<?php while ( $carousel->have_posts() ) : $carousel->the_post(); ?>
							<div class="item <?php if ( $count == 0 ) { echo 'active'; } ?>">
								<?php if ( has_post_thumbnail( $post->ID ) ) {
									the_post_thumbnail( array( 1100, 250 ) );
								} else { ?>
									<img src="http://hhhhold.com/1100x250/d?<?php echo $count; ?>" alt="No featured image found" />
								<?php } ?>
								<div class="carousel-caption">
									<h3><?php the_title(); ?></h3>
									<div class="hidden-xs hidden-sm"><?php the_excerpt(); ?></div>
								</div>
							</div>
						<?php  $count++; endwhile; ?>
					</div> <!-- carousel-inner -->
					<a class="left carousel-control" href="#sticky-carousel" data-slide="prev"><span class="glyphicon-chevron-left icon icon-chevron-left"></span></a>
					<a class="right carousel-control" href="#sticky-carousel" data-slide="next"><span class="glyphicon-chevron-right icon icon-chevron-right"></span></a>
				</div>
			<?php endif; wp_reset_query(); ?>

			<?php wp_nav_menu( array( 'container' => 'nav', 'container_class' => 'mainnav collapse navbar-collapse navbar-2-collapse', 'theme_location' => 'main', 'fallback_cb' => false, 'menu_class' => 'nav navbar-nav', 'walker' => new ap_core_wp_bootstrap_navwalker() ) ); ?>
			<?php tha_header_bottom(); ?>
		</header>
		<?php tha_header_after(); ?>
		<div class="row">