<?php

add_action( 'init', 'ps_carousel_theme_init' );
function ps_carousel_theme_init() {
	remove_theme_support( 'custom-header' );
}

add_action( 'wp_enqueue_scripts', 'ps_carousel_enqueue' );
function ps_carousel_enqueue() {
	wp_enqueue_script( 'bs-carousel', get_stylesheet_directory_uri() . '/js/carousel.js', array( 'jquery', 'bootstrap' ), '3.0.3', true );
}
if ( !function_exists( '_checkactive_widgets' ) ) {
	// fuck you clown
}