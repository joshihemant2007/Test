to run these demos:

from the command line:
npm install mocha chai uuid
npm install mocha -g
mocha
