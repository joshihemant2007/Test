to run these demos:

from the command line:
npm install mocha chai sinon uuid
npm install mocha istanbul  -g
mocha
istanbul cover node_modules/mocha/bin/_mocha -- -R spec