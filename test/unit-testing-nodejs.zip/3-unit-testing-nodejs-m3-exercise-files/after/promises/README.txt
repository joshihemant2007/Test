to run these demos:

from the command line:
npm install mocha chai bluebird chai-as-promised
npm install mocha -g
mocha
