to run these demos:

from the command line:
npm install mocha chai bluebird
npm install mocha -g
mocha
