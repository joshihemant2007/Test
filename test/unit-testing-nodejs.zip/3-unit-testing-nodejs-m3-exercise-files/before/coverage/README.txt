to run these demos:

from the command line:
npm install mocha chai sinon uuid
npm install mocha -g
mocha
