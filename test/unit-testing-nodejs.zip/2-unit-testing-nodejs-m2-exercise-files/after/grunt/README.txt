to run these demos:

from the command line:
npm install mocha chai grunt grunt-contrib-watch grunt-mocha-test
npm install mocha grunt-cli -g
grunt
