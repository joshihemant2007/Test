to run these demos:

from the command line:
npm install mocha chai gulp gulp-util gulp-mocha
npm install mocha gulp -g
gulp
