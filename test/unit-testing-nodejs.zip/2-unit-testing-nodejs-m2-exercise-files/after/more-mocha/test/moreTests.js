'use strict';

var chai = require('chai'),
  expect = chai.expect;
  
chai.should();

describe('some other tests', function() {
  it('should be true', function() {
    expect(true).to.be.true;
  });
});