The demos for this course can be found at the link below:

https://github.com/bmaluijb/GetYourLoanApp