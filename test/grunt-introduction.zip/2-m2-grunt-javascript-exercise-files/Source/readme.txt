In order to get these samples to run you will need to install the various npm packages.  These packages have been removed from these zip files to save space.

To install the packages you can do the following

1) CD into the working directory for the project
2) Enter the command 'npm install .' this will download all the npm packages.