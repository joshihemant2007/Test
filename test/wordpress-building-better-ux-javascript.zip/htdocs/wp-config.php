<?php


// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'pluralsight');

/** MySQL database username */
define('DB_USER', 'wp');

/** MySQL database password */
define('DB_PASSWORD', 'wp');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('AUTH_KEY',         '|x/HV1D@|Inb~*>e.Zwm$yAy5z-{>zXU&~|d:`n&C!cr92i$|N&;gc<5d[f5VjA,');
define('SECURE_AUTH_KEY',  '08N)8|25Y2[:0JqEgWfcGz>0@_x-Ty#SR@`XxBA7yM1~uv_~8U{9=qVhYW{)+aba');
define('LOGGED_IN_KEY',    'w`KN_@MHIJ->J|[+A$-09X9i77&1o,?4dg1Rn$P]dNTSX(1q9<ET7u>F5u^#XZq/');
define('NONCE_KEY',        'Y%P[[.a|lnUAtjKAv@Jd  lB0929y~5!rA|sxE3Ci%q{+.edNk:DWv!gSr!bQofy');
define('AUTH_SALT',        'Qa.SMHM?n_7)w<&n;Fhq5j,77dxc(Bb4H5|)Ek@B+w[|i|l>^<|i6zM4 4)WxMf1');
define('SECURE_AUTH_SALT', '~2q#%bd3/@CPhbt+~35u<T#f{o!H*P)(s,1^5d?W<-J)R3)3*ur%@J0l0GiqCy5o');
define('LOGGED_IN_SALT',   ']n41W#sNE[fxA*;IRc0#P9>s_OY|{K,h{TR^D`c{TKGJ;(wO+vh3NY2zBzL9V,K-');
define('NONCE_SALT',       'Af:G4?;2P6DyF1G/zi@`g9{6rc4e5a_r&w:^w<=SH-DL3Ilmjn^|G[[?1J it[#c');


$table_prefix = 'wp_';

define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
