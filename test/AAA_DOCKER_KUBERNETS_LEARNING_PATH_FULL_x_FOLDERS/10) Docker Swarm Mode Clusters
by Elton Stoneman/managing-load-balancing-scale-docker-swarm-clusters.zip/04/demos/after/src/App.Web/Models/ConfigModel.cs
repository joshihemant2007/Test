
namespace App.Web.Models
{
    public class ConfigModel
    {
        public string ApiUrl {get; set;}
    }
}
