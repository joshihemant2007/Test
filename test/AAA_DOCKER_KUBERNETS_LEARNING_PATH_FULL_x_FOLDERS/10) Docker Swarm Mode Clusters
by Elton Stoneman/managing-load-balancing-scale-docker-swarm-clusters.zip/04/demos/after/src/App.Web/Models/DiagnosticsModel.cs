
namespace App.Web.Models
{
    public class DiagnosticsModel
    {
        public string Version {get; set;}

        public string Server {get; set;}
    }
}
