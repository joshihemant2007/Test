
namespace App.Api.Models
{
    public class PasswordResponse
    {
        public string Password {get; set;}

        public string ApiVersion {get; set;}

        public string ApiServer {get; set;}
    }
}
