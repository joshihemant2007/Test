To access the lab materials for this course, go to:

https://github.com/g0t4/docker-swarm-mode-getting-started
