namespace ApiConsumer.Models
{
    public class HomeModel
    {
        public string ServerName {get; set;}

        public string ApiResponse { get; set; }

        public bool ApiResponseCached {get; set;}
    }
}