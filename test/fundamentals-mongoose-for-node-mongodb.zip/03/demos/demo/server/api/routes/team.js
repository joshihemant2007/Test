

module.exports = function (router) {
	// GET: List of Team Members
	router.get('/team', function (req, res) {

	})
}