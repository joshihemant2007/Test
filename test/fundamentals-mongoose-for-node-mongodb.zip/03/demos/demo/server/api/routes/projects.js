

module.exports = function (router) {
	// GET: List of active projects
	router.get('/projects', function (req, res) { 
    
	})
}