

module.exports = function (router) {
	// GET: the 12 newest stand-up meeting notes
	router.get('/standup', function (req, res) {

	})
}