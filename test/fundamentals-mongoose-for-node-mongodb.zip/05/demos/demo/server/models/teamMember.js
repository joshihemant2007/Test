// TeamMember 

const mongoose = require('mongoose')

const teamMemberSchema = new mongoose.Schema({
	name: { type: String }
})

