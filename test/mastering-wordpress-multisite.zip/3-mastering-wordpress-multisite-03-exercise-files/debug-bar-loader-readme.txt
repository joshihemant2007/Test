Read Me First!

The debug-bar-loader.php must be copied into the /wp-content/mu-plugins folder with the entire debug-bar plugin directory. Debug Bar can be downloaded here: http://wordpress.org/plugins/debug-bar/

Once the debug-bar-loader.php is in mu-plugins.php, it will check the WP_DEBUG constant stored in the wp-config.php file. However, for testing purposes, you could -- if you wanted -- define WP_DEBUG inside the loader, regardless of how WP_DEBUG was defined in wp-config.php.

Have fun!