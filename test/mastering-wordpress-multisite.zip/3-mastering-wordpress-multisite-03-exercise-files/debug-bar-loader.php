<?php

	if ( defined( 'WP_DEBUG' ) && true == WP_DEBUG ) {
		require_once( 'debug-bar/debug-bar.php' );
	}
?>