<?php
/*
Plugin Name: Pluralsight Arbitrary Option Builder
Plugin URI: http://pluralsight.com/training/TableOfContents/mastering-wordpress-multisite/
Description: This creates an arbitrary option on a specific blog and updates it.
Version: 0.1
Author: Chris Reynolds
Author URI: http://jazzsequence.com/
*/

/**
 * Copyright (c) 2013 Chris Reynolds. All rights reserved.
 *
 * Released under the GPL license
 * http://www.opensource.org/licenses/gpl-license.php
 *
 * This is an add-on for WordPress
 * http://wordpress.org/
 *
 * **********************************************************************
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * **********************************************************************
 */

add_action( 'network_admin_menu', 'add_blog_option_demo_menu' );

function add_blog_option_demo_menu() {
	add_menu_page( 'WordPress Multisite Blog Option Demo', 'Blog Option Demo', 'manage_options', 'ps-ms-blog-option-demo', 'blog_option_demo_page' );
}

function blog_option_demo_page() {
	$blog_id = 9; // set this to any blog ID -- has to be a blog that exists

	// store the option value, if it exists
	$stored_value = get_blog_option( $blog_id, 'arbitrary_option' );
	if ( !$stored_value ) {
		// no stored option value exists -- this is the first time around
		$stored_value = 1;
		add_blog_option( $blog_id, 'arbitrary_option', $stored_value );
	} else {
		// a value exists, so let's change it
		$stored_value++;
		update_blog_option( $blog_id, 'arbitrary_option', $stored_value );
	}
	?>
	<div class="wrap">
		<h2>The Code:</h2>
		<pre>
			<?php
				echo htmlentities('
	$blog_id = 9; // set this to any blog ID -- has to be a blog that exists

	// store the option value, if it exists
	$stored_value = get_blog_option( $blog_id, \'arbitrary_option\' );
	if ( !$stored_value ) {
		// no stored option value exists -- this is the first time around
		$stored_value = 1;
		add_blog_option( $blog_id, \'arbitrary_option\', $stored_value );
	} else {
		// a value exists, so let\'s change it
		$stored_value++;
		update_blog_option( $blog_id, \'arbitrary_option\', $stored_value );
	}
				');
			?>
		</pre>
		<h2>The Result:</h2>
		<table class="form-table">
			<tr valign="top">
				<th scope="row"><label for="blog_id">Blog ID:</label></th>
				<td><?php echo $blog_id; ?></td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="arbitrary_option">Arbitrary Option Value:</label></th>
				<td><?php echo get_blog_option( $blog_id, 'arbitrary_option' ); ?></td>
			</tr>
		</table>
	</div>
	<?php
}