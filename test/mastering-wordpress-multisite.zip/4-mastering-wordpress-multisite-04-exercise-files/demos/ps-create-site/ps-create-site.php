<?php
/*
Plugin Name: Pluralsight Create Site
Plugin URI: http://pluralsight.com/training/TableOfContents/mastering-wordpress-multisite/
Description: This plugin will create a new site on a multisite network.
Author: Chris Reynolds
Version: 0.1
Author URI: http://chrisreynolds.io/
License: GPLv2
*/

/* Note: It's handy if you're using a theme that uses Bootstrap styles
to display the alerts and placeholder text.
Museum Core can handle this nicely but there may be others:
http://wordpress.org/themes/museum-core/
*/

// create my shortcode -- first parameter is shortcode to use, second parameter is the function
// usage: [create_site]
add_shortcode( 'create_site', 'ps_multisite_create_site' );

function ps_multisite_create_site() {
	// start my output buffer
	ob_start();

	// check if multisite is active
	if ( is_multisite() ) {

		// current user is going to be this new site's admin
		$current_user = wp_get_current_user();

		if ( isset( $_POST['create_site'] ) ) {
			$domain = esc_html( $_POST['domain'] );
			$path = esc_html( $_POST['path'] );
			$title = esc_html( $_POST['title'] );
			$user_id = absint( $_POST['user_id'] );

			// make sure we have all 4 required parameters
			if ( $domain && $path && $title && $user_id ) {

				// create a new site
				$new_site = wpmu_create_blog( $domain, $path, $title, $user_id );

				if ( $new_site ) {
					echo '<div class="updated alert alert-success">' . sprintf( __( 'New site %s created successfully!' ), $title ) . '</div>';
				}

			} else {
				echo '<div class="error alert alert-danger">' . __( 'New site could not be created. Please make sure you\'ve filled out all the fields.' ) . '</div>';

				// if the domain was not set
				if ( !$domain ) {
					echo '<div class="error alert alert-info">' . __( 'Domain was not set.' ) . '</div>';
				}

				// if the path was not set
				if ( !$path ) {
					echo '<div class="error alert alert-info">' . __( 'Path was not set.' ) . '</div>';
				}

				// if the site title was not set
				if ( !$title ) {
					echo '<div class="error alert alert-info">' . __( 'Title was not set.' ) . '</div>';
				}

				// if the admin user was not set (this will only be unset for logged-out users)
				if ( !$user_id ) {
					echo '<div class="error alert alert-info">' . __( 'Admin user was not set.' ) . '</div>';
				}
			}
		}
		?>

		<form method="post">

			<table class="form-table">
				<tr valign="top">
					<th scope="row">
						<label for="domain"><?php _e( 'Domain' ); ?></label>
					</th>
					<td>
						<input maxlength="45" size="25" name="domain" value="<?php if ( defined('DOMAIN_CURRENT_SITE') ) { echo DOMAIN_CURRENT_SITE; } ?>" />
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label for="path"><?php _e( 'Path' ); ?></label>
					</th>
					<td>
						<input maxlength="45" size="10" name="path" placeholder="<?php _e( '/your-path/' ); ?>" />
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label for="title"><?php _e( 'Site Title' ); ?></label>
					</th>
					<td>
						<input maxlength="45" size="25" name="title" placeholder="<?php _e( 'Your site title' ); ?>" />
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label for="user_id"><?php _e( 'Site Admin' ); ?></label>
					</th>
					<td>
						<input maxlength="45" id="disabledTextInput" size="10" name="user_login" placeholder="<?php echo $current_user->user_login; ?>" disabled />
						<input type="hidden" name="user_id" value="<?php echo $current_user->ID; ?>" />
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr valign="top">
					<td>
						<button name="create_site" class="btn btn-primary button-primary" /><?php _e( 'Create Site' ); ?></button>
					</td>
			</table>

		</form>

		<?php
	} else {
		// if multisite is not active
		?>
		<div class="alert alert-warning"><?php _e( 'Multisite is not active.' ); ?></div>
		<?php
	}
	// get the output buffer contents
	$output = ob_get_contents();
	// clean the output buffer
	ob_end_clean();
	// return the results
	return $output;

}