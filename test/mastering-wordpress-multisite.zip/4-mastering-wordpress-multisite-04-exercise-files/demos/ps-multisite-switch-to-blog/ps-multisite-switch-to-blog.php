<?php
/*
Plugin Name: Pluralsight Switch to Blog Example
Plugin URI: http://pluralsight.com/training/TableOfContents/mastering-wordpress-multisite/
Description: An example plugin to demonstrate switch_to_blog and restore_current_blog functionality that displays the recent posts from a specific site on the network.
Version: 0.1
Author: Chris Reynolds
Author URI: http://jazzsequence.com
*/

/**
 * Copyright (c) 2013 Chris Reynolds. All rights reserved.
 *
 * Released under the GPL license
 * http://www.opensource.org/licenses/gpl-license.php
 *
 * This is an add-on for WordPress
 * http://wordpress.org/
 *
 * **********************************************************************
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * **********************************************************************
 */

add_action( 'admin_menu', 'ps_ms_switch_to_blog_menu' );

function ps_ms_switch_to_blog_menu() {
	// create a top level menu item for our page
	add_menu_page( __( 'Multisite Switch' ), __( 'Multisite Switch' ), 'manage_options', 'ps-ms-switch', 'ps_ms_switch_to_blog_page' );
}

function ps_ms_switch_to_blog_page() {
	?>
	<h2>The code</h2>

	<pre>
		<?php echo htmlentities('
	if ( is_multisite() ) {

		$ps_lots_of_sites = wp_get_sites( array(\'public\' => 1 ));
		foreach ( $ps_lots_of_sites as $site ) {
			// let\'s set the blog id first
			$ps_blog_id = $site[\'blog_id\'];

			// get the name of the blog with get_blog_details
			$ps_blog_name = get_blog_details( $ps_blog_id )->blogname;

			// switch to the blog
			switch_to_blog( $ps_blog_id );

			// create a custom loop
			$recent_posts = new WP_Query();
			$recent_posts->query( \'posts_per_page=5\' );

			// do my loop
			if ( $recent_posts->have_posts() ) :
			echo \'<h2>\'. sprintf( __( \'Most recent posts from %s\' ), $ps_blog_name ) . \'</h2>\';

			while ( $recent_posts->have_posts() ) : $recent_posts->the_post();

			// echo the recent posts
			echo \'<a href="\' . get_permalink() . \'">\' . get_the_title() . \'</a><br />\';

			endwhile;

			else :

			echo \'<h2>\' . sprintf( __( \'No posts for %s were found.\' ), $ps_blog_name ) . \'</h2>\';

			endif;
			// go back to the old site
			restore_current_blog();
		}
		'); ?>
	</pre>

	<h2>The output</h2>
	<?php

	if ( is_multisite() ) {

		$ps_lots_of_sites = wp_get_sites( array('public' => 1 ));
		foreach ( $ps_lots_of_sites as $site ) {
			// let's set the blog id first
			$ps_blog_id = $site['blog_id'];

			// get the name of the blog with get_blog_details
			$ps_blog_name = get_blog_details( $ps_blog_id )->blogname;

			// switch to the blog
			switch_to_blog( $ps_blog_id );

			// create a custom loop
			$recent_posts = new WP_Query();
			$recent_posts->query( 'posts_per_page=5' );

			// do my loop
			if ( $recent_posts->have_posts() ) :
			echo '<h2>'. sprintf( __( 'Most recent posts from %s' ), $ps_blog_name ) . '</h2>';

			while ( $recent_posts->have_posts() ) : $recent_posts->the_post();

			// echo the recent posts
			echo '<a href="' . get_permalink() . '">' . get_the_title() . '</a><br />';

			endwhile;

			else :

			echo '<h2>' . sprintf( __( 'No posts for %s were found.' ), $ps_blog_name ) . '</h2>';

			endif;
			// go back to the old site
			restore_current_blog();
		}
	}
}